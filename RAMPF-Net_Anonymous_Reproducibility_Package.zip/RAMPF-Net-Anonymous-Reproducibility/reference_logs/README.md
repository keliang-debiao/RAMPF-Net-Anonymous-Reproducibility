# Reference Target Logs

The records in this directory are structured target outputs derived from the manuscript tables. They are provided to guide pipeline verification and AI-assisted execution planning.

They are not raw execution provenance. A completed computational run must write new logs under `outputs/`, together with predictions, checkpoints, selected temperatures, thresholds, support indices, software metadata, and file digests.
