# Reference Result Matrices

These files reproduce the numerical matrices reported in the manuscript. They support arithmetic checks, output-schema checks, and AI-assisted run planning. They are not substitutes for prediction files, checkpoints, environment captures, or machine-generated logs.

Values are stored at the manuscript reporting precision. Paired differences and inferential statistics in the study were computed from unrounded fold-level values; direct subtraction of rounded table entries can therefore differ by 0.001.
