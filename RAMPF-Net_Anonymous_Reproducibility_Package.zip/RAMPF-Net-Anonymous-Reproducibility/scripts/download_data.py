#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import kagglehub

from rampfnet.config import load_config
from rampfnet.utils import sha256_file, write_json


def copy_release(slug: str, destination: Path) -> list[dict[str, str | int]]:
    source = Path(kagglehub.dataset_download(slug))
    destination.mkdir(parents=True, exist_ok=True)
    records = []
    for path in source.rglob("*"):
        if not path.is_file():
            continue
        target = destination / path.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        records.append(
            {
                "path": str(target),
                "bytes": target.stat().st_size,
                "sha256": sha256_file(target),
            }
        )
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    raw = Path(config["data"]["raw_dir"])
    manifest = {
        "tripadvisor": copy_release(config["data"]["tripadvisor_slug"], raw / "tripadvisor"),
        "yelp": copy_release(config["data"]["yelp_slug"], raw / "yelp"),
    }
    write_json(Path(config["data"]["processed_dir"]) / "source_manifest.json", manifest)


if __name__ == "__main__":
    main()

