#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from rampfnet.calibration import apply_temperature
from rampfnet.config import load_config
from rampfnet.metrics import classification_metrics, stratified_bootstrap_interval
from rampfnet.splits import load_fold
from rampfnet.splits import ClassBalancedSupportSampler
from rampfnet.training import FoldTrainer
from rampfnet.utils import write_json


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    if any(
        config["evaluation"][key]
        for key in ["external_weight_update", "external_recalibration", "external_threshold_selection"]
    ):
        raise ValueError("Strict external evaluation requires all update switches to remain false")
    processed = Path(config["data"]["processed_dir"])
    output = Path(config["project"]["output_dir"])
    development = pd.read_csv(processed / "tripadvisor.csv.gz")
    external = pd.read_csv(processed / "yelp_test.csv.gz")
    probabilities = []
    for fold_number in range(1, int(config["data"]["outer_folds"]) + 1):
        fold = load_fold(processed / "folds", fold_number)
        trainer = FoldTrainer(config, development, fold, output)
        fold_dir = output / f"fold_{fold_number}"
        trainer.model.load_state_dict(torch.load(fold_dir / "model.pt", map_location=trainer.device))
        selection = __import__("json").loads((fold_dir / "selection.json").read_text(encoding="utf-8"))
        trainer.temperature = float(selection["temperature"])
        # External records are appended only for prediction; the support sampler remains
        # restricted to the development outer-training partition.
        offset = len(development)
        combined = pd.concat([development, external.assign(row_id=external.row_id + offset)], ignore_index=True)
        trainer.frame = combined
        trainer.dataset = __import__("rampfnet.data", fromlist=["ReviewDataset"]).ReviewDataset(combined)
        trainer.sampler = ClassBalancedSupportSampler(combined, fold.train, trainer.seed)
        prediction = trainer.predict(np.arange(offset, offset + len(external)))
        probabilities.append(apply_temperature(prediction["satisfaction_logits"], trainer.temperature))
    ensemble = np.mean(probabilities, axis=0)
    labels = external["satisfaction"].to_numpy()
    metrics = classification_metrics(labels, ensemble, bins=int(config["evaluation"]["ece_bins"]))
    replicates = int(config["evaluation"]["bootstrap_replicates"])
    seed = int(config["project"]["seed"])
    intervals = {
        metric: stratified_bootstrap_interval(labels, ensemble, metric, replicates, seed)
        for metric in ["accuracy", "macro_f1"]
    }
    external_output = output / "external"
    external_output.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(
        {
            "row_id": external["row_id"],
            "label": labels,
            "p_low": ensemble[:, 0],
            "p_medium": ensemble[:, 1],
            "p_high": ensemble[:, 2],
        }
    ).to_csv(external_output / "predictions.csv.gz", index=False)
    write_json(external_output / "metrics.json", {"metrics": metrics, "intervals": intervals})


if __name__ == "__main__":
    main()

