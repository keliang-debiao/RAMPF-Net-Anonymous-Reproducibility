#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from rampfnet.config import load_config


def save_figure(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(path, dpi=315, bbox_inches="tight", facecolor="white")
    plt.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--source", choices=["outputs", "reference"], default="outputs")
    args = parser.parse_args()
    config = load_config(args.config)
    root = Path(config["project"]["output_dir"])
    source = Path("reference_results") if args.source == "reference" else root
    target = root / "figures"

    internal_path = source / "internal_folds.csv" if args.source == "reference" else root / "fold_metrics.csv"
    if not internal_path.exists():
        raise FileNotFoundError(f"Required result file not found: {internal_path}")
    internal = pd.read_csv(internal_path)
    fold_rows = internal[internal["split"].str.startswith("fold_")] if "split" in internal else internal
    plt.figure(figsize=(7.2, 4.4))
    for metric in ["accuracy", "macro_f1", "qwk"]:
        plt.plot(np.arange(1, len(fold_rows) + 1), fold_rows[metric], marker="o", label=metric)
    plt.xlabel("Outer fold")
    plt.ylabel("Score")
    plt.xticks(np.arange(1, len(fold_rows) + 1))
    plt.legend(frameon=False)
    save_figure(target / "figure_3_cross_validation.png")

    if args.source == "reference":
        baseline = pd.read_csv(source / "baseline_internal.csv")
        plt.figure(figsize=(9.0, 4.8))
        positions = np.arange(len(baseline))
        plt.bar(positions, baseline["macro_f1"], yerr=baseline["macro_f1_sd"], capsize=3)
        plt.xticks(positions, baseline["model"], rotation=35, ha="right")
        plt.ylabel("Macro-F1")
        save_figure(target / "figure_4_baselines.png")

        external = pd.read_csv(source / "external.csv").dropna(subset=["macro_f1"])
        plt.figure(figsize=(7.8, 4.5))
        plt.barh(external["model"], external["macro_f1"])
        plt.xlabel("External macro-F1")
        save_figure(target / "figure_5_external.png")

        ablation = pd.read_csv(source / "ablation.csv")
        plt.figure(figsize=(8.2, 4.6))
        plt.barh(ablation["configuration"], ablation["macro_f1"])
        plt.xlabel("Macro-F1")
        save_figure(target / "figure_6_ablation.png")

        robustness = pd.read_csv(source / "robustness.csv")
        plt.figure(figsize=(9.0, 4.8))
        plt.bar(np.arange(len(robustness)), robustness["macro_f1"])
        plt.xticks(np.arange(len(robustness)), robustness["condition"], rotation=40, ha="right")
        plt.ylabel("Macro-F1")
        save_figure(target / "figure_7_robustness.png")

        interpretation = pd.read_csv(source / "interpretability.csv")
        aspects = interpretation[interpretation["analysis"] == "aspect_attribution"]
        plt.figure(figsize=(7.2, 4.4))
        plt.barh(aspects["level"], aspects["estimate"])
        plt.xlabel("Normalized absolute attribution")
        save_figure(target / "figure_8_interpretability.png")


if __name__ == "__main__":
    main()

