#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from rampfnet.config import load_config
from rampfnet.splits import make_outer_folds, save_folds
from rampfnet.utils import write_json


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    processed = Path(config["data"]["processed_dir"])
    frame = pd.read_csv(processed / "tripadvisor.csv.gz")
    folds = make_outer_folds(
        frame,
        n_splits=int(config["data"]["outer_folds"]),
        seed=int(config["project"]["seed"]),
        inner_fraction=float(config["data"]["inner_validation_fraction"]),
    )
    save_folds(folds, processed / "folds")
    write_json(
        processed / "folds" / "summary.json",
        {
            "folds": [
                {
                    "fold": item.fold,
                    "train": len(item.train),
                    "inner_train": len(item.inner_train),
                    "inner_validation": len(item.inner_validation),
                    "test": len(item.test),
                }
                for item in folds
            ]
        },
    )


if __name__ == "__main__":
    main()

