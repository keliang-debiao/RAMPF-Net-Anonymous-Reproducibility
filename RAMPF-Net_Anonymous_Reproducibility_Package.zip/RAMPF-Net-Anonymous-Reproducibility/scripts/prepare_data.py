#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from rampfnet.config import load_config
from rampfnet.data import read_tripadvisor, read_yelp_full
from rampfnet.utils import sha256_file, write_json


def select_csv(root: Path, preferred: tuple[str, ...]) -> Path:
    files = list(root.rglob("*.csv"))
    if not files:
        raise FileNotFoundError(f"No CSV file found below {root}")
    for name in preferred:
        for path in files:
            if path.name.lower() == name.lower():
                return path
    return max(files, key=lambda path: path.stat().st_size)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    raw = Path(config["data"]["raw_dir"])
    processed = Path(config["data"]["processed_dir"])
    processed.mkdir(parents=True, exist_ok=True)
    trip_path = select_csv(raw / "tripadvisor", ("tripadvisor_hotel_reviews.csv",))
    yelp_path = select_csv(raw / "yelp", ("test.csv", "yelp_review_full_csv_test.csv"))
    trip = read_tripadvisor(trip_path)
    yelp = read_yelp_full(yelp_path)
    expected_trip = int(config["data"]["tripadvisor_rows"])
    expected_yelp = int(config["data"]["yelp_test_rows"])
    if len(trip) != expected_trip:
        raise ValueError(f"TripAdvisor row count {len(trip)} does not match {expected_trip}")
    if len(yelp) != expected_yelp:
        raise ValueError(f"Yelp test row count {len(yelp)} does not match {expected_yelp}")
    trip.to_csv(processed / "tripadvisor.csv.gz", index=False)
    yelp.to_csv(processed / "yelp_test.csv.gz", index=False)
    write_json(
        processed / "audit.json",
        {
            "tripadvisor": {
                "rows": len(trip),
                "star_counts": trip["rating"].value_counts().sort_index().to_dict(),
                "class_counts": trip["satisfaction"].value_counts().sort_index().to_dict(),
                "duplicate_groups": int(trip["text_hash"].duplicated(keep=False).groupby(trip["text_hash"]).any().sum()),
                "source_sha256": sha256_file(trip_path),
            },
            "yelp": {
                "rows": len(yelp),
                "star_counts": yelp["rating"].value_counts().sort_index().to_dict(),
                "class_counts": yelp["satisfaction"].value_counts().sort_index().to_dict(),
                "source_sha256": sha256_file(yelp_path),
            },
        },
    )


if __name__ == "__main__":
    main()

