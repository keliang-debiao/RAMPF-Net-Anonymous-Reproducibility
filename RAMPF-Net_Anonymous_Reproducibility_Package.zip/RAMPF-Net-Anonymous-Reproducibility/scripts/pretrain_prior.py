#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from safetensors.torch import save_file

from rampfnet.config import load_config
from rampfnet.model import PriorFittedContextCore
from rampfnet.utils import set_seed


def task_batch(kind: str, support: int, query: int, dim: int, seed: int):
    rng = np.random.default_rng(seed)
    features = rng.normal(size=(support + query, dim)).astype("float32")
    weights = rng.normal(size=(dim, 3)).astype("float32")
    if kind == "linear":
        logits = features @ weights
    elif kind == "nonlinear":
        logits = np.tanh(features) @ weights + 0.2 * (features**2) @ abs(weights)
    elif kind == "mixture":
        centers = rng.normal(scale=1.5, size=(3, dim)).astype("float32")
        labels = rng.integers(0, 3, size=support + query)
        features = features + centers[labels]
        logits = -np.stack([((features - center) ** 2).mean(1) for center in centers], axis=1)
    else:
        logits = features @ weights + 0.5 * np.stack(
            [features[:, 0] * features[:, 1], features[:, 2] * features[:, 3], features[:, 4] * features[:, 5]],
            axis=1,
        )
    labels = logits.argmax(axis=1).astype("int64")
    return features[:support], labels[:support], features[support:], labels[support:]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    prior = config["prior"]
    seed = int(config["project"]["seed"])
    set_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    core = PriorFittedContextCore(
        int(prior["feature_dim"]),
        int(prior["classes"]),
        int(prior["attention_heads"]),
        int(prior["layers"]),
        0.1,
    ).to(device)
    head = torch.nn.Linear(int(prior["feature_dim"]), int(prior["classes"])).to(device)
    optimizer = torch.optim.AdamW(
        list(core.parameters()) + list(head.parameters()),
        lr=float(prior["learning_rate"]),
        weight_decay=float(prior["weight_decay"]),
    )
    generators = list(prior["generators"])
    counter = 0
    for epoch in range(int(prior["epochs"])):
        core.train()
        for task in range(int(prior["tasks_per_epoch"])):
            kind = generators[(epoch + task) % len(generators)]
            support_x, support_y, query_x, query_y = task_batch(
                kind,
                int(prior["support_size"]),
                int(prior["query_size"]),
                int(prior["feature_dim"]),
                seed + counter,
            )
            counter += 1
            support_tokens = torch.tensor(support_x, device=device).unsqueeze(1)
            query_tokens = torch.tensor(query_x, device=device).unsqueeze(1)
            support_labels = torch.tensor(support_y, device=device)
            targets = torch.tensor(query_y, device=device)
            representation = core(query_tokens, support_tokens, support_labels)
            loss = F.cross_entropy(head(representation), targets)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(list(core.parameters()) + list(head.parameters()), 1.0)
            optimizer.step()
    target = Path(config["project"]["output_checkpoint"])
    target.parent.mkdir(parents=True, exist_ok=True)
    save_file({key: value.detach().cpu() for key, value in core.state_dict().items()}, str(target))


if __name__ == "__main__":
    main()

