#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from rampfnet.config import load_config, load_yaml
from rampfnet.splits import load_fold
from rampfnet.training import FoldTrainer


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--variant", default="all")
    args = parser.parse_args()
    config = load_config(args.config)
    variants = load_yaml(args.config)["variants"]
    variants = [item for item in variants if args.variant in ("all", item["name"])]
    processed = Path(config["data"]["processed_dir"])
    frame = pd.read_csv(processed / "tripadvisor.csv.gz")
    output = Path(config["project"]["output_dir"]) / "ablations"
    records = []
    for variant in variants:
        for fold_number in range(1, int(config["data"]["outer_folds"]) + 1):
            fold = load_fold(processed / "folds", fold_number)
            trainer = FoldTrainer(config, frame, fold, output / variant["name"], variant=variant)
            trainer.fit(fold.inner_train, fold.inner_validation)
            trainer.refit(fold.train)
            metrics = trainer.evaluate_and_save(fold.test, "outer_test")
            records.append(
                {
                    "variant": variant["name"],
                    "fold": fold_number,
                    **metrics["classification"],
                    **{f"screening_{k}": v for k, v in metrics.get("screening", {}).items()},
                }
            )
    pd.DataFrame(records).to_csv(output / "fold_metrics.csv", index=False)


if __name__ == "__main__":
    main()

