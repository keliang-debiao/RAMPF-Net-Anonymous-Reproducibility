#!/usr/bin/env bash
set -euo pipefail

python scripts/download_data.py --config configs/main.yaml
python scripts/prepare_data.py --config configs/main.yaml
python scripts/make_splits.py --config configs/main.yaml
python scripts/pretrain_prior.py --config configs/prior_pretraining.yaml
python scripts/train_cv.py --config configs/main.yaml
python scripts/evaluate_external.py --config configs/main.yaml
python scripts/run_baselines.py --config configs/baselines.yaml
python scripts/run_mmpfn_comparator.py --config configs/main.yaml
python scripts/run_screening_baselines.py --config configs/main.yaml
python scripts/run_ablations.py --config configs/ablations.yaml
python scripts/run_robustness.py --config configs/robustness.yaml
python scripts/run_statistics.py --config configs/main.yaml
python scripts/generate_figures.py --config configs/main.yaml
python scripts/verify_package.py --root .
