#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from rampfnet.baselines import sequence_classifier, tfidf_logistic, transformer_classifier, xgboost_svd
from rampfnet.config import load_config, load_yaml
from rampfnet.splits import load_fold
from rampfnet.utils import write_json


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--model", default="all")
    args = parser.parse_args()
    merged = load_config(args.config)
    registry = load_yaml(args.config)["models"]
    processed = Path(merged["data"]["processed_dir"])
    output = Path(merged["project"]["output_dir"]) / "baselines"
    output.mkdir(parents=True, exist_ok=True)
    frame = pd.read_csv(processed / "tripadvisor.csv.gz")
    selected = [item for item in registry if args.model in ("all", item["name"])]
    selected = [
        item
        for item in selected
        if item["name"]
        not in {"absolute_deviation", "isolation_forest", "deviation_autoencoder", "mmpfn_adaptation"}
    ]
    records = []
    for fold_number in range(1, int(merged["data"]["outer_folds"]) + 1):
        fold = load_fold(processed / "folds", fold_number)
        train = frame.iloc[fold.train]
        test = frame.iloc[fold.test]
        for settings in selected:
            if settings["name"] == "tfidf_lr":
                result = tfidf_logistic(train, test, settings)
            elif settings["name"] == "xgboost_svd":
                result = xgboost_svd(train, test, settings)
            elif settings["name"] in {"textcnn", "bilstm"}:
                result = sequence_classifier(train, test, settings)
            elif settings["name"] == "deberta_v3_base":
                current = {
                    **settings,
                    "encoder": "microsoft/deberta-v3-base",
                    "epochs": 4,
                    "learning_rate": 0.00002,
                }
                result = transformer_classifier(train, test, current)
            else:
                result = transformer_classifier(train, test, settings)
            record = {"fold": fold_number, "model": result.name, **result.metrics}
            records.append(record)
            pd.DataFrame(result.probabilities).to_csv(
                output / f"{result.name}_fold_{fold_number}_probabilities.csv.gz", index=False
            )
    pd.DataFrame(records).to_csv(output / "fold_metrics.csv", index=False)
    write_json(output / "run_manifest.json", {"models": [item["name"] for item in selected]})


if __name__ == "__main__":
    main()

