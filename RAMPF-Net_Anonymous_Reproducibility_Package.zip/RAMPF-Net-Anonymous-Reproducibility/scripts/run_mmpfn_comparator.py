#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from rampfnet.config import load_config
from rampfnet.splits import load_fold
from rampfnet.training import FoldTrainer


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    processed = Path(config["data"]["processed_dir"])
    frame = pd.read_csv(processed / "tripadvisor.csv.gz")
    output = Path(config["project"]["output_dir"]) / "baselines" / "mmpfn_adaptation"
    variant = {
        "name": "mmpfn_adaptation",
        "use_ordinal_residual": False,
        "lambda_ordinal": 0.0,
        "lambda_inconsistency": 0.0,
        "lambda_contrastive": 0.10,
    }
    rows = []
    for fold_number in range(1, int(config["data"]["outer_folds"]) + 1):
        fold = load_fold(processed / "folds", fold_number)
        trainer = FoldTrainer(config, frame, fold, output, variant=variant)
        trainer.fit(fold.inner_train, fold.inner_validation)
        trainer.refit(fold.train)
        metrics = trainer.evaluate_and_save(fold.test, "outer_test")
        rows.append({"fold": fold_number, **metrics["classification"]})
    output.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output / "fold_metrics.csv", index=False)


if __name__ == "__main__":
    main()
