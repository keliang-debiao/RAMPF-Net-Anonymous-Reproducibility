#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from rampfnet.config import load_config, load_yaml
from rampfnet.perturbations import corrupt_labels, mask_tokens, stratified_subsample
from rampfnet.splits import FoldIndices, load_fold
from rampfnet.training import FoldTrainer


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--condition", default="all")
    args = parser.parse_args()
    config = load_config(args.config)
    conditions = load_yaml(args.config)["conditions"]
    conditions = [item for item in conditions if args.condition in ("all", item["name"])]
    processed = Path(config["data"]["processed_dir"])
    original = pd.read_csv(processed / "tripadvisor.csv.gz")
    output = Path(config["project"]["output_dir"]) / "robustness"
    records = []
    for condition in conditions:
        for fold_number in range(1, int(config["data"]["outer_folds"]) + 1):
            fold = load_fold(processed / "folds", fold_number)
            frame = original.copy()
            working_fold = fold
            seed = int(config["project"]["seed"]) + fold_number
            if "training_label_noise" in condition:
                frame.loc[fold.train, "satisfaction"] = corrupt_labels(
                    frame.loc[fold.train, "satisfaction"].to_numpy(),
                    float(condition["training_label_noise"]),
                    3,
                    seed,
                )
            if "training_fraction" in condition:
                selected = stratified_subsample(
                    frame.iloc[fold.train]["satisfaction"].to_numpy(),
                    float(condition["training_fraction"]),
                    seed,
                )
                reduced_train = fold.train[selected]
                reduced_inner_train = np.intersect1d(fold.inner_train, reduced_train)
                working_fold = FoldIndices(
                    fold.fold,
                    reduced_train,
                    reduced_inner_train,
                    fold.inner_validation,
                    fold.test,
                )
            trainer = FoldTrainer(config, frame, working_fold, output / condition["name"])
            trainer.fit(working_fold.inner_train, working_fold.inner_validation)
            trainer.refit(working_fold.train)
            if "token_mask_rate" in condition:
                frame.loc[working_fold.test, "text"] = [
                    mask_tokens(text, float(condition["token_mask_rate"]), seed + index)
                    for index, text in enumerate(frame.loc[working_fold.test, "text"])
                ]
                trainer.frame = frame
                trainer.dataset = __import__("rampfnet.data", fromlist=["ReviewDataset"]).ReviewDataset(frame)
            metrics = trainer.evaluate_and_save(working_fold.test, "outer_test")
            records.append(
                {
                    "condition": condition["name"],
                    "fold": fold_number,
                    **metrics["classification"],
                }
            )
    output.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(records).to_csv(output / "fold_metrics.csv", index=False)


if __name__ == "__main__":
    main()

