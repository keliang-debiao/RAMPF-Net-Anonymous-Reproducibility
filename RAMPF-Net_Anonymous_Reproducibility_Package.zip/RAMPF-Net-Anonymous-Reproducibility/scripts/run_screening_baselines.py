#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.neural_network import MLPRegressor

from rampfnet.config import load_config
from rampfnet.metrics import screening_metrics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    root = Path(config["project"]["output_dir"])
    rows = []
    for fold in range(1, int(config["data"]["outer_folds"]) + 1):
        prediction_path = root / f"fold_{fold}" / "outer_test_predictions.csv.gz"
        frame = pd.read_csv(prediction_path)
        residual_cols = [f"residual_{index}" for index in range(7)]
        if not set(residual_cols + ["weak_target"]).issubset(frame.columns):
            raise ValueError("Prediction files must include residual coordinates and weak targets")
        residual = frame[residual_cols].to_numpy()
        labels = frame["weak_target"].to_numpy(dtype=int)
        absolute_score = residual[:, 0]
        rows.append(
            {"fold": fold, "method": "absolute_deviation", **screening_metrics(labels, absolute_score, 2.0)}
        )
        isolation = IsolationForest(n_estimators=500, random_state=20261013 + fold).fit(residual)
        isolation_score = -isolation.score_samples(residual)
        threshold = float(np.quantile(isolation_score, 1.0 - labels.mean()))
        rows.append(
            {"fold": fold, "method": "isolation_forest", **screening_metrics(labels, isolation_score, threshold)}
        )
        autoencoder = MLPRegressor(
            hidden_layer_sizes=(32, 8, 32),
            activation="relu",
            max_iter=500,
            random_state=20261013 + fold,
        ).fit(residual, residual)
        reconstruction = autoencoder.predict(residual)
        score = ((reconstruction - residual) ** 2).mean(axis=1)
        threshold = float(np.quantile(score, 1.0 - labels.mean()))
        rows.append(
            {"fold": fold, "method": "deviation_autoencoder", **screening_metrics(labels, score, threshold)}
        )
    target = root / "screening_baselines"
    target.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(target / "fold_metrics.csv", index=False)


if __name__ == "__main__":
    main()

