#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from rampfnet.config import load_config
from rampfnet.statistics import corrected_resampled_test, holm_adjust


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--proposed", default="RAMPF-Net")
    args = parser.parse_args()
    config = load_config(args.config)
    root = Path(config["project"]["output_dir"])
    path = root / "baselines" / "fold_metrics.csv"
    proposed_path = root / "cross_validation_summary.json"
    if not path.exists() or not proposed_path.exists():
        raise FileNotFoundError("Run the five-fold study and baseline runners before statistics")
    baseline = pd.read_csv(path)
    proposed = np.array(
        __import__("json").loads(proposed_path.read_text(encoding="utf-8"))["macro_f1"]["folds"]
    )
    comparisons = []
    for model, group in baseline.groupby("model", sort=False):
        current = group.sort_values("fold")["macro_f1"].to_numpy()
        test = corrected_resampled_test(
            proposed,
            current,
            test_train_ratio=float(config["statistics"]["corrected_test_ratio"]),
            confidence=float(config["evaluation"]["confidence_level"]),
        )
        comparisons.append({"comparator": model, **test.__dict__})
    adjusted = holm_adjust([row["p_value"] for row in comparisons])
    for row, value in zip(comparisons, adjusted):
        row["holm_p"] = value
    pd.DataFrame(comparisons).to_csv(root / "statistical_comparisons.csv", index=False)


if __name__ == "__main__":
    main()

