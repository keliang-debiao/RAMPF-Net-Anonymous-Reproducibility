#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from rampfnet.config import load_config
from rampfnet.splits import load_fold
from rampfnet.training import FoldTrainer, aggregate_fold_metrics
from rampfnet.utils import configure_logging, write_json


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--fold", type=int, default=0, help="0 runs all outer folds")
    args = parser.parse_args()
    config = load_config(args.config)
    configure_logging(config["logging"]["level"])
    processed = Path(config["data"]["processed_dir"])
    output = Path(config["project"]["output_dir"])
    frame = pd.read_csv(processed / "tripadvisor.csv.gz")
    selected = range(1, int(config["data"]["outer_folds"]) + 1) if args.fold == 0 else [args.fold]
    metrics = []
    fold_rows = []
    for fold_number in selected:
        fold = load_fold(processed / "folds", fold_number)
        trainer = FoldTrainer(config, frame, fold, output)
        trainer.fit(fold.inner_train, fold.inner_validation)
        trainer.refit(fold.train)
        current = trainer.evaluate_and_save(fold.test, "outer_test")
        metrics.append(current)
        fold_rows.append({"fold": fold_number, **current["classification"]})
    if args.fold == 0:
        write_json(output / "cross_validation_summary.json", aggregate_fold_metrics(metrics))
        pd.DataFrame(fold_rows).to_csv(output / "fold_metrics.csv", index=False)


if __name__ == "__main__":
    main()

