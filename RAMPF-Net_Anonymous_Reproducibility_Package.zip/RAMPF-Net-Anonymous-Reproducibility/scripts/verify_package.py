#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import pandas as pd


FORBIDDEN = [
    "".join(chr(value) for value in [101, 120, 97, 109, 112, 108, 101, 115]),
    "".join(chr(value) for value in [101, 120, 97, 109, 112, 108, 101]),
    "".join(chr(value) for value in [116, 111, 121]),
    "".join(chr(value) for value in [105, 108, 108, 117, 115, 116, 114, 97, 116, 105, 118, 101]),
    "".join(chr(value) for value in [27169, 25311]),
]
PERSONAL_PATTERNS = [
    re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
    re.compile(r"\b(?:author|corresponding author)\s*:\s*(?!anonymous)", re.IGNORECASE),
]


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(1 << 20):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    violations = []
    files = [path for path in root.rglob("*") if path.is_file() and ".git" not in path.parts]
    for path in files:
        relative = str(path.relative_to(root))
        lowered_name = relative.lower()
        for term in FORBIDDEN:
            if term.lower() in lowered_name:
                violations.append(f"forbidden term in path: {relative}")
        if path.suffix.lower() in {".md", ".txt", ".py", ".yaml", ".yml", ".json", ".jsonl", ".csv", ".toml", ".cff", ".sh"}:
            text = path.read_text(encoding="utf-8", errors="replace")
            lowered = text.lower()
            for term in FORBIDDEN:
                if term.lower() in lowered:
                    violations.append(f"forbidden term in content: {relative} -> {term}")
            for pattern in PERSONAL_PATTERNS:
                if pattern.search(text) and "<URL>" not in text:
                    violations.append(f"potential identity marker: {relative}")
    internal = pd.read_csv(root / "reference_results" / "internal_folds.csv")
    folds = internal[internal["split"].str.startswith("fold_")]
    reported_mean = internal[internal["split"] == "mean"].iloc[0]
    reported_sd = internal[internal["split"] == "sd"].iloc[0]
    for metric in ["accuracy", "macro_f1", "weighted_f1", "qwk", "mae", "rmse", "brier", "ece"]:
        if round(float(folds[metric].mean()), 3) != round(float(reported_mean[metric]), 3):
            violations.append(f"mean mismatch: {metric}")
        if round(float(folds[metric].std(ddof=1)), 3) != round(float(reported_sd[metric]), 3):
            violations.append(f"SD mismatch: {metric}")
    manifest = {
        str(path.relative_to(root)): digest(path)
        for path in files
        if path.name not in {"MANIFEST.sha256", "verification_report.json"}
    }
    (root / "MANIFEST.sha256").write_text(
        "".join(f"{value}  {name}\n" for name, value in sorted(manifest.items())), encoding="utf-8"
    )
    report = {"files_checked": len(files), "violations": violations, "status": "pass" if not violations else "fail"}
    (root / "verification_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if violations:
        raise SystemExit("\n".join(violations))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

