from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import yaml


TOKEN_RE = re.compile(r"[A-Za-z]+(?:[-'][A-Za-z]+)?")


def load_lexicon(path: str | Path) -> dict[str, list[str]]:
    with Path(path).open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle)
    return {str(key): [str(term).lower() for term in terms] for key, terms in value.items()}


def word_tokens(text: str) -> list[str]:
    return [match.group(0).lower() for match in TOKEN_RE.finditer(text)]


@dataclass(frozen=True)
class AspectPolarity:
    positive_share: float
    negative_share: float
    mentioned_count: int


def aspect_polarity(
    text: str,
    aspect_lexicon: dict[str, list[str]],
    polarity_lexicon: dict[str, list[str]],
    window: int = 5,
) -> AspectPolarity:
    tokens = word_tokens(text)
    positive = set(polarity_lexicon["positive"])
    negative = set(polarity_lexicon["negative"])
    positive_dominant = 0
    negative_dominant = 0
    mentioned = 0
    for terms in aspect_lexicon.values():
        term_set = set(terms)
        locations = [i for i, token in enumerate(tokens) if token in term_set]
        if not locations:
            continue
        mentioned += 1
        pos_strength = 0
        neg_strength = 0
        for location in locations:
            local = tokens[max(0, location - window) : min(len(tokens), location + window + 1)]
            pos_strength += sum(token in positive for token in local)
            neg_strength += sum(token in negative for token in local)
        positive_dominant += int(pos_strength > neg_strength)
        negative_dominant += int(neg_strength > pos_strength)
    if mentioned == 0:
        return AspectPolarity(0.0, 0.0, 0)
    return AspectPolarity(
        positive_share=positive_dominant / mentioned,
        negative_share=negative_dominant / mentioned,
        mentioned_count=mentioned,
    )


def aspect_conflict_score(rating: int, polarity: AspectPolarity) -> float:
    if polarity.mentioned_count == 0:
        return 0.0
    if rating >= 4:
        return float(polarity.negative_share)
    if rating <= 2:
        return float(polarity.positive_share)
    return 0.5 * abs(polarity.positive_share - polarity.negative_share)


def char_spans(text: str, terms: list[str]) -> list[tuple[int, int]]:
    spans: list[tuple[int, int]] = []
    for term in terms:
        pattern = re.compile(rf"(?<!\w){re.escape(term)}(?!\w)", flags=re.IGNORECASE)
        spans.extend((match.start(), match.end()) for match in pattern.finditer(text))
    return spans


def token_aspect_mask(offsets: np.ndarray, spans: list[tuple[int, int]]) -> np.ndarray:
    mask = np.zeros(len(offsets), dtype=bool)
    for index, (start, end) in enumerate(offsets):
        if end <= start:
            continue
        mask[index] = any(max(start, left) < min(end, right) for left, right in spans)
    return mask

