from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .metrics import classification_metrics


@dataclass
class BaselineResult:
    name: str
    probabilities: np.ndarray
    metrics: dict[str, float]


def tfidf_logistic(
    train: pd.DataFrame,
    test: pd.DataFrame,
    settings: dict[str, Any],
) -> BaselineResult:
    vectorizer = TfidfVectorizer(
        ngram_range=tuple(settings["ngram_range"]),
        max_features=int(settings["max_features"]),
        sublinear_tf=bool(settings["sublinear_tf"]),
        lowercase=True,
    )
    train_matrix = vectorizer.fit_transform(train["text"])
    test_matrix = vectorizer.transform(test["text"])
    best_model = None
    best_score = -np.inf
    # Selection is performed only on the supplied training partition.
    from sklearn.model_selection import StratifiedKFold, cross_val_score

    splitter = StratifiedKFold(n_splits=3, shuffle=True, random_state=20261013)
    for value in settings["c_grid"]:
        candidate = LogisticRegression(
            C=float(value),
            class_weight=settings["class_weight"],
            max_iter=2000,
            solver="lbfgs",
        )
        score = cross_val_score(
            candidate, train_matrix, train["satisfaction"], cv=splitter, scoring="f1_macro"
        ).mean()
        if score > best_score:
            best_score = float(score)
            best_model = candidate
    assert best_model is not None
    best_model.fit(train_matrix, train["satisfaction"])
    probabilities = best_model.predict_proba(test_matrix)
    return BaselineResult(
        "tfidf_lr",
        probabilities,
        classification_metrics(test["satisfaction"].to_numpy(), probabilities),
    )


def xgboost_svd(
    train: pd.DataFrame,
    test: pd.DataFrame,
    settings: dict[str, Any],
) -> BaselineResult:
    from xgboost import XGBClassifier

    components = min(int(settings["svd_components"]), len(train) - 1)
    pipeline = Pipeline(
        [
            ("tfidf", TfidfVectorizer(ngram_range=(1, 2), max_features=60000, sublinear_tf=True)),
            ("svd", TruncatedSVD(n_components=components, random_state=20261013)),
            ("scale", StandardScaler()),
            (
                "model",
                XGBClassifier(
                    n_estimators=int(settings["trees"]),
                    max_depth=int(settings["max_depth"]),
                    learning_rate=float(settings["learning_rate"]),
                    subsample=float(settings["subsample"]),
                    objective="multi:softprob",
                    num_class=3,
                    eval_metric="mlogloss",
                    random_state=20261013,
                ),
            ),
        ]
    )
    pipeline.fit(train["text"], train["satisfaction"])
    probabilities = pipeline.predict_proba(test["text"])
    return BaselineResult(
        "xgboost_svd",
        probabilities,
        classification_metrics(test["satisfaction"].to_numpy(), probabilities),
    )


def transformer_classifier(
    train: pd.DataFrame,
    test: pd.DataFrame,
    settings: dict[str, Any],
    batch_size: int = 16,
    seed: int = 20261013,
) -> BaselineResult:
    import torch
    from torch.utils.data import DataLoader, Dataset
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    class TextDataset(Dataset):
        def __init__(self, frame: pd.DataFrame, tokenizer):
            self.frame = frame.reset_index(drop=True)
            self.tokenizer = tokenizer

        def __len__(self):
            return len(self.frame)

        def __getitem__(self, index):
            row = self.frame.iloc[index]
            encoded = self.tokenizer(
                row.text,
                truncation=True,
                max_length=256,
                padding="max_length",
                return_tensors="pt",
            )
            return {
                "input_ids": encoded["input_ids"].squeeze(0),
                "attention_mask": encoded["attention_mask"].squeeze(0),
                "labels": torch.tensor(int(row.satisfaction)),
            }

    torch.manual_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tokenizer = AutoTokenizer.from_pretrained(settings["encoder"])
    model = AutoModelForSequenceClassification.from_pretrained(
        settings["encoder"], num_labels=3
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(settings["learning_rate"]))
    generator = torch.Generator().manual_seed(seed)
    train_loader = DataLoader(
        TextDataset(train, tokenizer), batch_size=batch_size, shuffle=True, generator=generator
    )
    for _ in range(int(settings["epochs"])):
        model.train()
        for batch in train_loader:
            batch = {key: value.to(device) for key, value in batch.items()}
            loss = model(**batch).loss
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
    model.eval()
    values = []
    test_loader = DataLoader(TextDataset(test, tokenizer), batch_size=batch_size, shuffle=False)
    with torch.no_grad():
        for batch in test_loader:
            labels = batch.pop("labels")
            del labels
            batch = {key: value.to(device) for key, value in batch.items()}
            values.append(torch.softmax(model(**batch).logits, dim=-1).cpu().numpy())
    probabilities = np.concatenate(values)
    return BaselineResult(
        settings["name"],
        probabilities,
        classification_metrics(test["satisfaction"].to_numpy(), probabilities),
    )


def sequence_classifier(
    train: pd.DataFrame,
    test: pd.DataFrame,
    settings: dict[str, Any],
    batch_size: int = 32,
    seed: int = 20261013,
) -> BaselineResult:
    import re

    import torch
    from collections import Counter
    from torch import nn
    from torch.utils.data import DataLoader, Dataset

    token_re = re.compile(r"[A-Za-z]+(?:[-'][A-Za-z]+)?")
    counter = Counter(
        token.lower()
        for text in train["text"]
        for token in token_re.findall(str(text))
    )
    vocabulary = {token: index + 2 for index, (token, _) in enumerate(counter.most_common(30000))}

    def encode(text: str) -> list[int]:
        values = [vocabulary.get(token.lower(), 1) for token in token_re.findall(str(text))][:256]
        return values or [1]

    class SequenceDataset(Dataset):
        def __init__(self, frame: pd.DataFrame):
            self.sequences = [encode(text) for text in frame["text"]]
            self.labels = frame["satisfaction"].to_numpy(dtype=np.int64)

        def __len__(self):
            return len(self.labels)

        def __getitem__(self, index):
            return self.sequences[index], int(self.labels[index])

    def collate(batch):
        length = max(len(item[0]) for item in batch)
        inputs = torch.zeros(len(batch), length, dtype=torch.long)
        labels = torch.tensor([item[1] for item in batch], dtype=torch.long)
        for row, (sequence, _) in enumerate(batch):
            inputs[row, : len(sequence)] = torch.tensor(sequence)
        return inputs, labels

    class TextCNN(nn.Module):
        def __init__(self):
            super().__init__()
            self.embedding = nn.Embedding(len(vocabulary) + 2, 128, padding_idx=0)
            self.convolutions = nn.ModuleList(
                nn.Conv1d(128, int(settings["filters"]), width)
                for width in settings["widths"]
            )
            self.dropout = nn.Dropout(float(settings["dropout"]))
            self.head = nn.Linear(int(settings["filters"]) * len(settings["widths"]), 3)

        def forward(self, inputs):
            embedded = self.embedding(inputs).transpose(1, 2)
            pooled = [torch.relu(layer(embedded)).amax(dim=-1) for layer in self.convolutions]
            return self.head(self.dropout(torch.cat(pooled, dim=-1)))

    class BiLSTM(nn.Module):
        def __init__(self):
            super().__init__()
            hidden = int(settings["hidden_size"])
            self.embedding = nn.Embedding(len(vocabulary) + 2, 128, padding_idx=0)
            self.recurrent = nn.LSTM(
                128,
                hidden,
                num_layers=int(settings["layers"]),
                bidirectional=True,
                dropout=float(settings["dropout"]),
                batch_first=True,
            )
            self.attention = nn.Linear(hidden * 2, 1)
            self.head = nn.Linear(hidden * 2, 3)

        def forward(self, inputs):
            values, _ = self.recurrent(self.embedding(inputs))
            mask = inputs.ne(0)
            scores = self.attention(values).squeeze(-1).masked_fill(~mask, -1e4)
            pooled = (torch.softmax(scores, dim=-1).unsqueeze(-1) * values).sum(dim=1)
            return self.head(pooled)

    torch.manual_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = TextCNN() if settings["name"] == "textcnn" else BiLSTM()
    model = model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=0.01)
    counts = train["satisfaction"].value_counts().reindex([0, 1, 2]).to_numpy()
    weights = torch.tensor(len(train) / (3.0 * counts), dtype=torch.float32, device=device)
    generator = torch.Generator().manual_seed(seed)
    loader = DataLoader(
        SequenceDataset(train),
        batch_size=batch_size,
        shuffle=True,
        collate_fn=collate,
        generator=generator,
    )
    for _ in range(8):
        model.train()
        for inputs, labels in loader:
            inputs, labels = inputs.to(device), labels.to(device)
            loss = torch.nn.functional.cross_entropy(model(inputs), labels, weight=weights)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
    model.eval()
    predictions = []
    with torch.no_grad():
        for inputs, _ in DataLoader(SequenceDataset(test), batch_size=batch_size, collate_fn=collate):
            predictions.append(torch.softmax(model(inputs.to(device)), dim=-1).cpu().numpy())
    probabilities = np.concatenate(predictions)
    return BaselineResult(
        settings["name"],
        probabilities,
        classification_metrics(test["satisfaction"].to_numpy(), probabilities),
    )

