from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize_scalar
from sklearn.linear_model import LogisticRegression


def softmax(logits: np.ndarray) -> np.ndarray:
    shifted = logits - logits.max(axis=1, keepdims=True)
    values = np.exp(shifted)
    return values / values.sum(axis=1, keepdims=True)


def fit_temperature(logits: np.ndarray, labels: np.ndarray) -> float:
    logits = np.asarray(logits, dtype=float)
    labels = np.asarray(labels, dtype=int)

    def objective(log_temperature: float) -> float:
        temperature = np.exp(log_temperature)
        probabilities = softmax(logits / temperature)
        return float(-np.log(probabilities[np.arange(len(labels)), labels].clip(1e-12)).mean())

    result = minimize_scalar(objective, bounds=(-3.0, 3.0), method="bounded")
    if not result.success:
        raise RuntimeError("Temperature optimization failed")
    return float(np.exp(result.x))


def apply_temperature(logits: np.ndarray, temperature: float) -> np.ndarray:
    if temperature <= 0:
        raise ValueError("Temperature must be positive")
    return softmax(np.asarray(logits, dtype=float) / float(temperature))


def select_f1_threshold(labels: np.ndarray, scores: np.ndarray, grid: np.ndarray) -> float:
    from sklearn.metrics import f1_score

    labels = np.asarray(labels, dtype=int)
    scores = np.asarray(scores, dtype=float)
    ranked = [(float(f1_score(labels, scores >= value, zero_division=0)), float(value)) for value in grid]
    ranked.sort(key=lambda item: (-item[0], item[1]))
    return ranked[0][1]


@dataclass(frozen=True)
class ConfidenceCalibration:
    slope: float
    intercept: float


def confidence_calibration(labels: np.ndarray, probabilities: np.ndarray) -> ConfidenceCalibration:
    labels = np.asarray(labels, dtype=int)
    probabilities = np.asarray(probabilities, dtype=float)
    confidence = probabilities.max(axis=1).clip(1e-7, 1 - 1e-7)
    correctness = (probabilities.argmax(axis=1) == labels).astype(int)
    logit_confidence = np.log(confidence / (1.0 - confidence)).reshape(-1, 1)
    model = LogisticRegression(C=1e6, solver="lbfgs").fit(logit_confidence, correctness)
    return ConfidenceCalibration(float(model.coef_[0, 0]), float(model.intercept_[0]))

