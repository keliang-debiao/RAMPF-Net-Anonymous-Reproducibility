from __future__ import annotations

from typing import Any

import numpy as np
import torch
from transformers import AutoTokenizer

from .aspects import char_spans, token_aspect_mask
from .data import ReviewRecord


class ReviewBatchCollator:
    def __init__(self, encoder_name: str, aspect_lexicon: dict[str, list[str]], max_length: int):
        self.tokenizer = AutoTokenizer.from_pretrained(encoder_name, use_fast=True)
        self.aspect_lexicon = aspect_lexicon
        self.aspect_names = list(aspect_lexicon)
        self.max_length = max_length

    def __call__(self, records: list[ReviewRecord]) -> dict[str, Any]:
        texts = [record.text for record in records]
        tokenized = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=self.max_length,
            return_offsets_mapping=True,
            return_tensors="pt",
        )
        offsets = tokenized.pop("offset_mapping").numpy()
        masks = np.zeros((len(records), len(self.aspect_names), offsets.shape[1]), dtype=bool)
        for row, text in enumerate(texts):
            for aspect, name in enumerate(self.aspect_names):
                spans = char_spans(text, self.aspect_lexicon[name])
                masks[row, aspect] = token_aspect_mask(offsets[row], spans)
        tokenized["aspect_masks"] = torch.from_numpy(masks)
        tokenized["row_id"] = torch.tensor([record.row_id for record in records], dtype=torch.long)
        tokenized["rating"] = torch.tensor([record.rating for record in records], dtype=torch.long)
        tokenized["satisfaction"] = torch.tensor(
            [record.satisfaction for record in records], dtype=torch.long
        )
        tokenized["text_hash"] = [record.text_hash for record in records]
        return tokenized

