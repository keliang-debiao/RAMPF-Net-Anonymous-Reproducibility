from __future__ import annotations

import html
import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from .utils import sha256_text


URL_RE = re.compile(r"(?:https?://|www\.)\S+", flags=re.IGNORECASE)
SPACE_RE = re.compile(r"\s+")


def normalize_text(value: str) -> str:
    text = unicodedata.normalize("NFKC", html.unescape(str(value)))
    text = URL_RE.sub(" <URL> ", text)
    return SPACE_RE.sub(" ", text).strip()


def satisfaction_label(rating: int) -> int:
    rating = int(rating)
    if rating in (1, 2):
        return 0
    if rating == 3:
        return 1
    if rating in (4, 5):
        return 2
    raise ValueError(f"Rating outside 1-5: {rating}")


def _find_column(frame: pd.DataFrame, names: Iterable[str]) -> str | None:
    lookup = {str(c).strip().lower(): c for c in frame.columns}
    for name in names:
        if name.lower() in lookup:
            return lookup[name.lower()]
    return None


def audit_frame(frame: pd.DataFrame, source: str) -> pd.DataFrame:
    text_col = _find_column(frame, ["review", "text", "review_text", "content"])
    rating_col = _find_column(frame, ["rating", "label", "stars", "class"])
    if text_col is None or rating_col is None:
        if frame.shape[1] == 2:
            first_numeric = pd.to_numeric(frame.iloc[:, 0], errors="coerce").notna().mean() > 0.95
            rating_col, text_col = (frame.columns[0], frame.columns[1]) if first_numeric else (
                frame.columns[1], frame.columns[0]
            )
        else:
            raise ValueError(f"Cannot resolve text and rating columns for {source}")
    audited = pd.DataFrame(
        {
            "text": frame[text_col].map(normalize_text),
            "rating": pd.to_numeric(frame[rating_col], errors="coerce"),
        }
    )
    audited = audited[audited["text"].str.len().gt(0) & audited["rating"].notna()].copy()
    audited["rating"] = audited["rating"].astype(int)
    if not audited["rating"].between(1, 5).all():
        observed = sorted(audited["rating"].unique().tolist())
        raise ValueError(f"Unexpected rating values for {source}: {observed}")
    audited["satisfaction"] = audited["rating"].map(satisfaction_label).astype(int)
    audited["text_hash"] = audited["text"].map(sha256_text)
    audited["row_id"] = np.arange(len(audited), dtype=np.int64)
    audited["source"] = source
    return audited[["row_id", "source", "text", "text_hash", "rating", "satisfaction"]]


def read_tripadvisor(path: str | Path) -> pd.DataFrame:
    return audit_frame(pd.read_csv(path), "tripadvisor")


def read_yelp_full(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    try:
        frame = pd.read_csv(path)
        if frame.shape[1] < 2:
            raise ValueError
    except (ValueError, pd.errors.ParserError):
        frame = pd.read_csv(path, header=None, names=["label", "text"])
    if _find_column(frame, ["review", "text", "review_text", "content"]) is None:
        frame = pd.read_csv(path, header=None, names=["label", "text"])
    return audit_frame(frame, "yelp")


@dataclass(frozen=True)
class ReviewRecord:
    row_id: int
    text: str
    text_hash: str
    rating: int
    satisfaction: int


class ReviewDataset:
    def __init__(self, frame: pd.DataFrame):
        self.frame = frame.reset_index(drop=True)

    def __len__(self) -> int:
        return len(self.frame)

    def __getitem__(self, index: int) -> ReviewRecord:
        row = self.frame.iloc[index]
        return ReviewRecord(
            row_id=int(row.row_id),
            text=str(row.text),
            text_hash=str(row.text_hash),
            rating=int(row.rating),
            satisfaction=int(row.satisfaction),
        )

