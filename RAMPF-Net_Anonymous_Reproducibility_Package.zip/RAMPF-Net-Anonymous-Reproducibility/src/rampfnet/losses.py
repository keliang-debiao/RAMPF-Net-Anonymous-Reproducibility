from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn.functional as F

from .model import RAMPFOutput


def focal_loss(
    logits: torch.Tensor,
    targets: torch.Tensor,
    class_weights: torch.Tensor,
    gamma: float = 2.0,
) -> torch.Tensor:
    log_probabilities = F.log_softmax(logits, dim=-1)
    probabilities = log_probabilities.exp()
    index = torch.arange(targets.size(0), device=targets.device)
    log_true = log_probabilities[index, targets]
    true_probability = probabilities[index, targets]
    alpha = class_weights[targets]
    return (-alpha * (1.0 - true_probability).pow(gamma) * log_true).mean()


def ordinal_cumulative_loss(rating_probabilities: torch.Tensor, ratings: torch.Tensor) -> torch.Tensor:
    stars = torch.arange(1, 5, device=ratings.device)
    targets = (ratings.unsqueeze(1) > stars.unsqueeze(0)).to(rating_probabilities.dtype)
    cumulative = torch.stack(
        [rating_probabilities[:, cut:].sum(dim=-1) for cut in range(1, 5)], dim=1
    )
    return F.binary_cross_entropy(cumulative.clamp(1e-7, 1 - 1e-7), targets)


def operational_weak_targets(
    residual_vector: torch.Tensor,
    absolute_threshold: float = 2.0,
    confidence_threshold: float = 0.60,
    aspect_threshold: float = 0.50,
) -> torch.Tensor:
    detached = residual_vector.detach()
    absolute = detached[:, 0]
    direction = detached[:, 3] > 0.5
    aspect_conflict = detached[:, 4]
    confidence = detached[:, 5]
    positive = ((absolute >= absolute_threshold) & (confidence >= confidence_threshold)) | (
        direction & (aspect_conflict >= aspect_threshold)
    )
    return positive.to(residual_vector.dtype)


def weighted_binary_loss(
    logits: torch.Tensor, targets: torch.Tensor, positive_weight: torch.Tensor
) -> torch.Tensor:
    return F.binary_cross_entropy_with_logits(logits, targets, pos_weight=positive_weight)


def contrastive_loss(original: torch.Tensor, augmented: torch.Tensor, temperature: float) -> torch.Tensor:
    original = F.normalize(original, dim=-1)
    augmented = F.normalize(augmented, dim=-1)
    logits = original @ augmented.T / temperature
    targets = torch.arange(original.size(0), device=original.device)
    return 0.5 * (F.cross_entropy(logits, targets) + F.cross_entropy(logits.T, targets))


@dataclass
class LossBundle:
    total: torch.Tensor
    satisfaction: torch.Tensor
    ordinal: torch.Tensor
    inconsistency: torch.Tensor
    contrastive: torch.Tensor
    weak_targets: torch.Tensor


def combined_loss(
    output: RAMPFOutput,
    augmented_representation: torch.Tensor,
    satisfaction_targets: torch.Tensor,
    rating_targets: torch.Tensor,
    class_weights: torch.Tensor,
    positive_weight: torch.Tensor,
    config: dict,
) -> LossBundle:
    if output.residual_vector is None or output.inconsistency_logits is None:
        raise ValueError("The complete objective requires an active screening path")
    training = config["training"]
    screening = config["screening"]
    satisfaction = focal_loss(
        output.satisfaction_logits,
        satisfaction_targets,
        class_weights,
        gamma=float(training["focal_gamma"]),
    )
    ordinal = ordinal_cumulative_loss(output.rating_probabilities, rating_targets)
    weak_targets = operational_weak_targets(
        output.residual_vector,
        float(screening["absolute_deviation_threshold"]),
        float(screening["posterior_confidence_threshold"]),
        float(screening["aspect_conflict_threshold"]),
    )
    inconsistency = weighted_binary_loss(
        output.inconsistency_logits, weak_targets, positive_weight
    )
    contrastive = contrastive_loss(
        output.satisfaction_representation,
        augmented_representation,
        float(training["contrastive_temperature"]),
    )
    total = (
        satisfaction
        + float(training["lambda_ordinal"]) * ordinal
        + float(training["lambda_inconsistency"]) * inconsistency
        + float(training["lambda_contrastive"]) * contrastive
    )
    return LossBundle(total, satisfaction, ordinal, inconsistency, contrastive, weak_targets)

