from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    cohen_kappa_score,
    f1_score,
    log_loss,
    mean_absolute_error,
    mean_squared_error,
    precision_score,
    recall_score,
    roc_auc_score,
)


def multiclass_brier(y_true: np.ndarray, probabilities: np.ndarray, classes: int = 3) -> float:
    targets = np.eye(classes, dtype=float)[np.asarray(y_true, dtype=int)]
    return float(np.mean(np.sum((probabilities - targets) ** 2, axis=1)))


def calibration_errors(
    y_true: np.ndarray, probabilities: np.ndarray, bins: int = 15
) -> tuple[float, float]:
    y_true = np.asarray(y_true)
    probabilities = np.asarray(probabilities)
    confidence = probabilities.max(axis=1)
    predictions = probabilities.argmax(axis=1)
    correctness = predictions == y_true
    edges = np.linspace(0.0, 1.0, bins + 1)
    expected = 0.0
    maximum = 0.0
    for left, right in zip(edges[:-1], edges[1:]):
        include = (confidence >= left) & (confidence < right if right < 1.0 else confidence <= right)
        if not include.any():
            continue
        gap = abs(float(correctness[include].mean()) - float(confidence[include].mean()))
        expected += include.mean() * gap
        maximum = max(maximum, gap)
    return float(expected), float(maximum)


def classification_metrics(y_true: np.ndarray, probabilities: np.ndarray, bins: int = 15) -> dict[str, float]:
    y_true = np.asarray(y_true, dtype=int)
    probabilities = np.asarray(probabilities, dtype=float)
    predictions = probabilities.argmax(axis=1)
    ece, mce = calibration_errors(y_true, probabilities, bins)
    return {
        "accuracy": float(accuracy_score(y_true, predictions)),
        "macro_f1": float(f1_score(y_true, predictions, average="macro")),
        "weighted_f1": float(f1_score(y_true, predictions, average="weighted")),
        "qwk": float(cohen_kappa_score(y_true, predictions, weights="quadratic")),
        "mae": float(mean_absolute_error(y_true, predictions)),
        "rmse": float(mean_squared_error(y_true, predictions) ** 0.5),
        "brier": multiclass_brier(y_true, probabilities, probabilities.shape[1]),
        "nll": float(log_loss(y_true, probabilities, labels=np.arange(probabilities.shape[1]))),
        "ece": ece,
        "mce": mce,
    }


def screening_metrics(y_true: np.ndarray, scores: np.ndarray, threshold: float) -> dict[str, float]:
    y_true = np.asarray(y_true, dtype=int)
    scores = np.asarray(scores, dtype=float)
    predictions = scores >= threshold
    return {
        "precision": float(precision_score(y_true, predictions, zero_division=0)),
        "recall": float(recall_score(y_true, predictions, zero_division=0)),
        "f1": float(f1_score(y_true, predictions, zero_division=0)),
        "auroc": float(roc_auc_score(y_true, scores)),
        "auprc": float(average_precision_score(y_true, scores)),
    }


def mean_sd_ci(values: np.ndarray, confidence: float = 0.95) -> dict[str, float]:
    from scipy.stats import t

    values = np.asarray(values, dtype=float)
    mean = float(values.mean())
    sd = float(values.std(ddof=1))
    quantile = float(t.ppf(0.5 + confidence / 2.0, df=len(values) - 1))
    half = quantile * sd / np.sqrt(len(values))
    return {"mean": mean, "sd": sd, "ci_low": mean - half, "ci_high": mean + half}


def stratified_bootstrap_interval(
    y_true: np.ndarray,
    probabilities: np.ndarray,
    metric: str,
    replicates: int,
    seed: int,
    confidence: float = 0.95,
) -> tuple[float, float]:
    y_true = np.asarray(y_true, dtype=int)
    probabilities = np.asarray(probabilities, dtype=float)
    rng = np.random.default_rng(seed)
    by_class = [np.flatnonzero(y_true == label) for label in np.unique(y_true)]
    values = []
    for _ in range(replicates):
        sampled = np.concatenate([rng.choice(index, size=len(index), replace=True) for index in by_class])
        current = classification_metrics(y_true[sampled], probabilities[sampled])
        values.append(current[metric])
    alpha = (1.0 - confidence) / 2.0
    return float(np.quantile(values, alpha)), float(np.quantile(values, 1.0 - alpha))


@dataclass(frozen=True)
class MetricTolerance:
    metric: str
    target: float
    absolute_tolerance: float

    def accepts(self, observed: float) -> bool:
        return abs(float(observed) - self.target) <= self.absolute_tolerance

