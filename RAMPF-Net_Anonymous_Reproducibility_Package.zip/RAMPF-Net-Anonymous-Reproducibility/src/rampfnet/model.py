from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch
from peft import LoraConfig, TaskType, get_peft_model
from safetensors.torch import load_file
from torch import nn
from transformers import AutoModel


class MaskedAspectPooling(nn.Module):
    def __init__(self, hidden_size: int, aspects: int, output_dim: int):
        super().__init__()
        self.queries = nn.Parameter(torch.empty(aspects, hidden_size))
        self.projection = nn.Linear(hidden_size, output_dim)
        self.missing = nn.Parameter(torch.empty(aspects, output_dim))
        self.norm = nn.LayerNorm(output_dim)
        nn.init.normal_(self.queries, std=0.02)
        nn.init.normal_(self.missing, std=0.02)

    def forward(self, hidden: torch.Tensor, masks: torch.Tensor) -> torch.Tensor:
        # hidden: [B,L,H], masks: [B,M,L]
        scores = torch.einsum("blh,mh->bml", hidden, self.queries) / math.sqrt(hidden.size(-1))
        valid = masks.any(dim=-1)
        safe_masks = masks.clone()
        safe_masks[~valid] = True
        scores = scores.masked_fill(~safe_masks, torch.finfo(scores.dtype).min)
        weights = torch.softmax(scores, dim=-1)
        pooled = torch.einsum("bml,blh->bmh", weights, hidden)
        pooled = self.norm(self.projection(pooled))
        missing = self.missing.unsqueeze(0).expand(hidden.size(0), -1, -1)
        return torch.where(valid.unsqueeze(-1), pooled, missing)


class BalancedMultiviewProjector(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        embedding_dim: int,
        projection_heads: int,
        aspects: int,
        balance_queries: int,
        attention_heads: int,
        dropout: float,
    ):
        super().__init__()
        self.gates = nn.ModuleList(nn.Linear(hidden_size, embedding_dim) for _ in range(projection_heads))
        self.values = nn.ModuleList(nn.Linear(hidden_size, embedding_dim) for _ in range(projection_heads))
        self.aspect_pool = MaskedAspectPooling(hidden_size, aspects, embedding_dim)
        self.balance_queries = nn.Parameter(torch.empty(balance_queries, embedding_dim))
        self.balance_attention = nn.MultiheadAttention(
            embedding_dim, attention_heads, dropout=dropout, batch_first=True
        )
        self.norm = nn.LayerNorm(embedding_dim)
        nn.init.normal_(self.balance_queries, std=0.02)

    def forward(
        self,
        global_hidden: torch.Tensor,
        token_hidden: torch.Tensor,
        aspect_masks: torch.Tensor,
        use_aspects: bool = True,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        global_tokens = torch.stack(
            [torch.sigmoid(gate(global_hidden)) * value(global_hidden) for gate, value in zip(self.gates, self.values)],
            dim=1,
        )
        aspect_tokens = self.aspect_pool(token_hidden, aspect_masks)
        views = torch.cat([global_tokens, aspect_tokens], dim=1) if use_aspects else global_tokens
        queries = self.balance_queries.unsqueeze(0).expand(views.size(0), -1, -1)
        balanced, _ = self.balance_attention(queries, views, views, need_weights=False)
        return self.norm(balanced + queries), aspect_tokens


class PriorFittedContextCore(nn.Module):
    def __init__(self, dim: int, classes: int, heads: int, layers: int, dropout: float):
        super().__init__()
        self.label_embedding = nn.Embedding(classes, dim)
        self.support_projection = nn.Linear(dim * 2, dim)
        self.cross_attention = nn.MultiheadAttention(dim, heads, dropout=dropout, batch_first=True)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=dim,
            nhead=heads,
            dim_feedforward=dim * 4,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=layers)
        self.norm = nn.LayerNorm(dim)

    def forward(
        self,
        query_tokens: torch.Tensor,
        support_tokens: torch.Tensor,
        support_labels: torch.Tensor,
    ) -> torch.Tensor:
        # One query batch uses one query-excluded support context.
        support_summary = support_tokens.mean(dim=1)
        label_features = self.label_embedding(support_labels)
        support_context = self.support_projection(torch.cat([support_summary, label_features], dim=-1))
        support_context = support_context.unsqueeze(0).expand(query_tokens.size(0), -1, -1)
        attended, _ = self.cross_attention(
            query_tokens, support_context, support_context, need_weights=False
        )
        encoded = self.encoder(self.norm(query_tokens + attended))
        return encoded.mean(dim=1)

    def load_prior(self, path: str | Path, strict: bool = True) -> None:
        path = Path(path)
        if not path.exists():
            if strict:
                raise FileNotFoundError(f"Required prior-core checkpoint not found: {path}")
            return
        missing, unexpected = self.load_state_dict(load_file(str(path)), strict=False)
        if strict and (missing or unexpected):
            raise RuntimeError(f"Prior checkpoint mismatch; missing={missing}, unexpected={unexpected}")


class MLPContextCore(nn.Module):
    def __init__(self, dim: int, dropout: float):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(dim, dim * 2), nn.GELU(), nn.Dropout(dropout), nn.Linear(dim * 2, dim)
        )

    def forward(
        self,
        query_tokens: torch.Tensor,
        support_tokens: torch.Tensor,
        support_labels: torch.Tensor,
    ) -> torch.Tensor:
        del support_tokens, support_labels
        return self.network(query_tokens.mean(dim=1))


class OrdinalResidualTokenizer(nn.Module):
    def __init__(self, output_dim: int):
        super().__init__()
        self.project = nn.Sequential(nn.Linear(7, output_dim), nn.GELU(), nn.LayerNorm(output_dim))

    @staticmethod
    def rating_region(value: torch.Tensor) -> torch.Tensor:
        return torch.where(value < 2.5, 0, torch.where(value < 3.5, 1, 2))

    def forward(
        self,
        rating_posterior: torch.Tensor,
        observed_rating: torch.Tensor,
        aspect_conflict: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        stars = torch.arange(1, 6, device=rating_posterior.device, dtype=rating_posterior.dtype)
        implied = (rating_posterior * stars.unsqueeze(0)).sum(dim=-1)
        observed = observed_rating.to(rating_posterior.dtype)
        signed = implied - observed
        absolute = signed.abs()
        normalized = absolute / 4.0
        direction = (self.rating_region(implied) != self.rating_region(observed)).to(rating_posterior.dtype)
        confidence = rating_posterior.max(dim=-1).values
        entropy = -(rating_posterior * rating_posterior.clamp_min(1e-8).log()).sum(dim=-1)
        vector = torch.stack(
            [absolute, signed, normalized, direction, aspect_conflict, confidence, entropy], dim=-1
        )
        return self.project(vector), vector, implied


@dataclass
class RAMPFOutput:
    satisfaction_logits: torch.Tensor
    satisfaction_probabilities: torch.Tensor
    satisfaction_representation: torch.Tensor
    rating_logits: torch.Tensor
    rating_probabilities: torch.Tensor
    implied_rating: torch.Tensor
    residual_vector: torch.Tensor | None
    residual_gate: torch.Tensor | None
    inconsistency_logits: torch.Tensor | None
    inconsistency_probabilities: torch.Tensor | None


class RAMPFNet(nn.Module):
    def __init__(self, config: dict[str, Any], replace_prior_core: bool = False):
        super().__init__()
        model_cfg = config["model"]
        self.encoder = AutoModel.from_pretrained(model_cfg["encoder_name"])
        for parameter in self.encoder.parameters():
            parameter.requires_grad = False
        lora = LoraConfig(
            task_type=TaskType.FEATURE_EXTRACTION,
            r=int(model_cfg["adapter_rank"]),
            lora_alpha=int(model_cfg["adapter_alpha"]),
            lora_dropout=float(model_cfg["adapter_dropout"]),
            target_modules=["query_proj", "key_proj", "value_proj"],
            layers_to_transform=list(model_cfg["adapter_layers"]),
            layers_pattern="layer",
        )
        self.encoder = get_peft_model(self.encoder, lora)
        hidden = int(self.encoder.config.hidden_size)
        dim = int(model_cfg["embedding_dim"])
        self.projector = BalancedMultiviewProjector(
            hidden,
            dim,
            int(model_cfg["projection_heads"]),
            len(model_cfg["aspect_names"]),
            int(model_cfg["balance_queries"]),
            int(model_cfg["attention_heads"]),
            float(model_cfg["dropout"]),
        )
        if replace_prior_core:
            self.core = MLPContextCore(dim, float(model_cfg["dropout"]))
        else:
            self.core = PriorFittedContextCore(
                dim,
                classes=3,
                heads=int(model_cfg["attention_heads"]),
                layers=int(model_cfg["prior_layers"]),
                dropout=float(model_cfg["dropout"]),
            )
            self.core.load_prior(
                model_cfg["prior_checkpoint"], strict=bool(model_cfg["strict_prior_checkpoint"])
            )
        self.satisfaction_projection = nn.Linear(dim, dim)
        self.rating_projection = nn.Linear(dim, dim)
        self.satisfaction_head = nn.Linear(dim, 3)
        self.rating_head = nn.Linear(dim, 5)
        self.residual_tokenizer = OrdinalResidualTokenizer(dim)
        self.residual_gate = nn.Sequential(nn.Linear(dim + 2, 1), nn.Sigmoid())
        self.inconsistency_head = nn.Linear(dim * 2, 1)

    def encode(
        self, batch: dict[str, torch.Tensor], use_aspects: bool = True
    ) -> tuple[torch.Tensor, torch.Tensor]:
        encoded = self.encoder(
            input_ids=batch["input_ids"],
            attention_mask=batch["attention_mask"],
            return_dict=True,
        ).last_hidden_state
        global_hidden = encoded[:, 0]
        return self.projector(global_hidden, encoded, batch["aspect_masks"], use_aspects=use_aspects)

    def forward_from_tokens(
        self,
        query_tokens: torch.Tensor,
        support_tokens: torch.Tensor,
        support_labels: torch.Tensor,
        observed_rating: torch.Tensor | None = None,
        aspect_conflict: torch.Tensor | None = None,
        use_residual: bool = True,
        use_gate: bool = True,
    ) -> RAMPFOutput:
        core = self.core(query_tokens, support_tokens, support_labels)
        satisfaction_representation = torch.tanh(self.satisfaction_projection(core))
        rating_representation = torch.tanh(self.rating_projection(core))
        satisfaction_logits = self.satisfaction_head(satisfaction_representation)
        rating_logits = self.rating_head(rating_representation)
        satisfaction_probabilities = torch.softmax(satisfaction_logits, dim=-1)
        rating_probabilities = torch.softmax(rating_logits, dim=-1)
        stars = torch.arange(1, 6, device=rating_logits.device, dtype=rating_logits.dtype)
        implied_rating = (rating_probabilities * stars.unsqueeze(0)).sum(dim=-1)
        residual_vector = None
        gate = None
        inconsistency_logits = None
        inconsistency_probabilities = None
        if observed_rating is not None and use_residual:
            if aspect_conflict is None:
                raise ValueError("aspect_conflict is required when the screening path is active")
            residual_token, residual_vector, implied_rating = self.residual_tokenizer(
                rating_probabilities, observed_rating, aspect_conflict
            )
            confidence = residual_vector[:, 5:6]
            entropy = residual_vector[:, 6:7]
            gate = self.residual_gate(torch.cat([satisfaction_representation, confidence, entropy], dim=-1))
            if not use_gate:
                gate = torch.ones_like(gate)
            modulated = gate * residual_token
            inconsistency_logits = self.inconsistency_head(
                torch.cat([satisfaction_representation, modulated], dim=-1)
            ).squeeze(-1)
            inconsistency_probabilities = torch.sigmoid(inconsistency_logits)
        return RAMPFOutput(
            satisfaction_logits=satisfaction_logits,
            satisfaction_probabilities=satisfaction_probabilities,
            satisfaction_representation=satisfaction_representation,
            rating_logits=rating_logits,
            rating_probabilities=rating_probabilities,
            implied_rating=implied_rating,
            residual_vector=residual_vector,
            residual_gate=gate,
            inconsistency_logits=inconsistency_logits,
            inconsistency_probabilities=inconsistency_probabilities,
        )

    def forward(
        self,
        query_batch: dict[str, torch.Tensor],
        support_batch: dict[str, torch.Tensor],
        support_labels: torch.Tensor,
        observed_rating: torch.Tensor | None = None,
        aspect_conflict: torch.Tensor | None = None,
        use_residual: bool = True,
        use_gate: bool = True,
    ) -> RAMPFOutput:
        query_tokens, _ = self.encode(query_batch)
        support_tokens, _ = self.encode(support_batch)
        return self.forward_from_tokens(
            query_tokens,
            support_tokens,
            support_labels,
            observed_rating,
            aspect_conflict,
            use_residual,
            use_gate,
        )

