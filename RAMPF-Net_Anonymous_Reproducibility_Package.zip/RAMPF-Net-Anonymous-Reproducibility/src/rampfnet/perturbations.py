from __future__ import annotations

import numpy as np


def mask_tokens(text: str, rate: float, seed: int) -> str:
    if not 0 <= rate <= 1:
        raise ValueError("Masking rate must be within [0,1]")
    tokens = text.split()
    rng = np.random.default_rng(seed)
    count = int(round(len(tokens) * rate))
    if count == 0:
        return text
    positions = rng.choice(len(tokens), size=min(count, len(tokens)), replace=False)
    for position in positions:
        tokens[int(position)] = "[MASK]"
    return " ".join(tokens)


def corrupt_labels(labels: np.ndarray, rate: float, classes: int, seed: int) -> np.ndarray:
    labels = np.asarray(labels, dtype=int).copy()
    rng = np.random.default_rng(seed)
    count = int(round(len(labels) * rate))
    positions = rng.choice(len(labels), size=count, replace=False)
    for position in positions:
        alternatives = [label for label in range(classes) if label != labels[position]]
        labels[position] = rng.choice(alternatives)
    return labels


def stratified_subsample(labels: np.ndarray, fraction: float, seed: int) -> np.ndarray:
    labels = np.asarray(labels, dtype=int)
    rng = np.random.default_rng(seed)
    selected = []
    for label in np.unique(labels):
        indices = np.flatnonzero(labels == label)
        count = max(1, int(round(len(indices) * fraction)))
        selected.append(rng.choice(indices, size=count, replace=False))
    result = np.concatenate(selected)
    rng.shuffle(result)
    return result


def polarity_reversal_ratings(ratings: np.ndarray, seed: int) -> np.ndarray:
    ratings = np.asarray(ratings, dtype=int).copy()
    rng = np.random.default_rng(seed)
    positive = ratings >= 4
    negative = ratings <= 2
    ratings[positive] = rng.choice([1, 2], size=int(positive.sum()))
    ratings[negative] = rng.choice([4, 5], size=int(negative.sum()))
    return ratings

