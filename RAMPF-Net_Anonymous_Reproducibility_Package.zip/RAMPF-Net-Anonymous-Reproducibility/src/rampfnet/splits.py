from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold, StratifiedShuffleSplit


@dataclass(frozen=True)
class FoldIndices:
    fold: int
    train: np.ndarray
    inner_train: np.ndarray
    inner_validation: np.ndarray
    test: np.ndarray


def make_outer_folds(
    frame: pd.DataFrame,
    n_splits: int = 5,
    seed: int = 20261013,
    inner_fraction: float = 0.15,
) -> list[FoldIndices]:
    splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    labels = frame["satisfaction"].to_numpy()
    groups = frame["text_hash"].to_numpy()
    all_rows = np.arange(len(frame))
    folds: list[FoldIndices] = []
    for fold, (train, test) in enumerate(splitter.split(all_rows, labels, groups), start=1):
        unique_groups = frame.iloc[train].drop_duplicates("text_hash").copy()
        inner = StratifiedShuffleSplit(n_splits=1, test_size=inner_fraction, random_state=seed + fold)
        group_train, group_val = next(
            inner.split(unique_groups.index.to_numpy(), unique_groups["satisfaction"].to_numpy())
        )
        train_hashes = set(unique_groups.iloc[group_train]["text_hash"])
        val_hashes = set(unique_groups.iloc[group_val]["text_hash"])
        inner_train = train[np.isin(groups[train], list(train_hashes))]
        inner_validation = train[np.isin(groups[train], list(val_hashes))]
        item = FoldIndices(fold, train, inner_train, inner_validation, test)
        assert_no_group_overlap(frame, item)
        folds.append(item)
    return folds


def assert_no_group_overlap(frame: pd.DataFrame, fold: FoldIndices) -> None:
    hash_sets = {
        "inner_train": set(frame.iloc[fold.inner_train]["text_hash"]),
        "inner_validation": set(frame.iloc[fold.inner_validation]["text_hash"]),
        "test": set(frame.iloc[fold.test]["text_hash"]),
    }
    pairs = [("inner_train", "inner_validation"), ("inner_train", "test"), ("inner_validation", "test")]
    for left, right in pairs:
        overlap = hash_sets[left] & hash_sets[right]
        if overlap:
            raise AssertionError(f"Normalized-text group overlap in fold {fold.fold}: {left}/{right}")


def save_folds(folds: list[FoldIndices], output_dir: str | Path) -> None:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    for item in folds:
        np.savez_compressed(
            output_dir / f"fold_{item.fold}.npz",
            train=item.train,
            inner_train=item.inner_train,
            inner_validation=item.inner_validation,
            test=item.test,
        )


def load_fold(path: str | Path, fold: int) -> FoldIndices:
    values = np.load(Path(path) / f"fold_{fold}.npz")
    return FoldIndices(
        fold=fold,
        train=values["train"],
        inner_train=values["inner_train"],
        inner_validation=values["inner_validation"],
        test=values["test"],
    )


class ClassBalancedSupportSampler:
    def __init__(self, frame: pd.DataFrame, candidate_indices: np.ndarray, seed: int):
        self.frame = frame
        self.candidate_indices = np.asarray(candidate_indices)
        self.seed = seed

    def sample(self, query_indices: np.ndarray, size: int, context: int = 0) -> np.ndarray:
        query_indices = np.asarray(query_indices)
        excluded_hashes = set(self.frame.iloc[query_indices]["text_hash"])
        pool = self.candidate_indices[
            ~self.frame.iloc[self.candidate_indices]["text_hash"].isin(excluded_hashes).to_numpy()
        ]
        if np.intersect1d(pool, query_indices).size:
            raise AssertionError("A query row remains in the support pool")
        rng = np.random.default_rng(self.seed + 1009 * context + int(query_indices.sum()))
        labels = self.frame.iloc[pool]["satisfaction"].to_numpy()
        quotas = [size // 3, size // 3, size - 2 * (size // 3)]
        selected: list[np.ndarray] = []
        for label, quota in enumerate(quotas):
            candidates = pool[labels == label]
            if candidates.size == 0:
                raise ValueError(f"No support candidates for class {label}")
            selected.append(rng.choice(candidates, size=quota, replace=candidates.size < quota))
        result = np.concatenate(selected)
        rng.shuffle(result)
        return result.astype(np.int64)

