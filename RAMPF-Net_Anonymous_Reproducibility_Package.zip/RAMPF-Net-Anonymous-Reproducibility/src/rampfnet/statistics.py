from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.stats import t


@dataclass(frozen=True)
class CorrectedComparison:
    mean_difference: float
    ci_low: float
    ci_high: float
    statistic: float
    p_value: float
    hedges_g_av: float


def corrected_resampled_test(
    proposed: np.ndarray,
    comparator: np.ndarray,
    test_train_ratio: float = 0.25,
    confidence: float = 0.95,
) -> CorrectedComparison:
    proposed = np.asarray(proposed, dtype=float)
    comparator = np.asarray(comparator, dtype=float)
    if proposed.shape != comparator.shape or proposed.ndim != 1:
        raise ValueError("Paired fold vectors must have the same one-dimensional shape")
    difference = proposed - comparator
    folds = len(difference)
    mean_difference = float(difference.mean())
    variance = float(difference.var(ddof=1))
    corrected_se = float(np.sqrt((1.0 / folds + test_train_ratio) * variance))
    statistic = mean_difference / corrected_se if corrected_se > 0 else np.inf
    p_value = float(2.0 * t.sf(abs(statistic), df=folds - 1))
    critical = float(t.ppf(0.5 + confidence / 2.0, df=folds - 1))
    pooled_av = float(np.sqrt((proposed.var(ddof=1) + comparator.var(ddof=1)) / 2.0))
    raw_effect = mean_difference / pooled_av if pooled_av > 0 else np.inf
    correction = 1.0 - 3.0 / (4.0 * (2 * folds) - 9.0)
    effect = correction * raw_effect
    return CorrectedComparison(
        mean_difference=mean_difference,
        ci_low=mean_difference - critical * corrected_se,
        ci_high=mean_difference + critical * corrected_se,
        statistic=float(statistic),
        p_value=p_value,
        hedges_g_av=float(effect),
    )


def holm_adjust(p_values: list[float]) -> list[float]:
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    count = len(values)
    for rank, index in enumerate(order):
        candidate = min(1.0, (count - rank) * values[index])
        running = max(running, candidate)
        adjusted[index] = running
    return adjusted.tolist()

