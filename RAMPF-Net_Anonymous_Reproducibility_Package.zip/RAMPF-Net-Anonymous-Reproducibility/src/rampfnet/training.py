from __future__ import annotations

import copy
import json
import logging
import math
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.optim import AdamW
from torch.utils.data import DataLoader, Subset
from tqdm import tqdm

from .aspects import aspect_conflict_score, aspect_polarity, load_lexicon
from .calibration import apply_temperature, fit_temperature, select_f1_threshold
from .collate import ReviewBatchCollator
from .data import ReviewDataset, ReviewRecord
from .losses import (
    combined_loss,
    contrastive_loss,
    focal_loss,
    operational_weak_targets,
    ordinal_cumulative_loss,
)
from .metrics import classification_metrics, screening_metrics
from .model import RAMPFNet
from .splits import ClassBalancedSupportSampler, FoldIndices
from .utils import JsonlLogger, set_seed, write_json


LOGGER = logging.getLogger(__name__)


def move_batch(batch: dict[str, Any], device: torch.device) -> dict[str, Any]:
    return {key: value.to(device) if torch.is_tensor(value) else value for key, value in batch.items()}


def crop_and_drop(record: ReviewRecord, seed: int, drop_rate: float, minimum_fraction: float) -> ReviewRecord:
    tokens = record.text.split()
    if len(tokens) < 4:
        return record
    rng = np.random.default_rng(seed)
    retained = max(2, int(math.ceil(len(tokens) * minimum_fraction)))
    if retained < len(tokens):
        start = int(rng.integers(0, len(tokens) - retained + 1))
        tokens = tokens[start : start + retained]
    keep = rng.random(len(tokens)) >= drop_rate
    if not keep.any():
        keep[int(rng.integers(0, len(tokens)))] = True
    return replace(record, text=" ".join(np.asarray(tokens, dtype=object)[keep].tolist()))


class FoldTrainer:
    def __init__(
        self,
        config: dict[str, Any],
        frame: pd.DataFrame,
        fold: FoldIndices,
        output_dir: str | Path,
        variant: dict[str, Any] | None = None,
    ):
        self.config = copy.deepcopy(config)
        self.frame = frame.reset_index(drop=True)
        self.fold = fold
        self.variant = variant or {"name": "full"}
        for key in ["lambda_ordinal", "lambda_inconsistency", "lambda_contrastive"]:
            if key in self.variant:
                self.config["training"][key] = float(self.variant[key])
        self.output_dir = Path(output_dir) / f"fold_{fold.fold}"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.seed = int(config["project"]["seed"]) + fold.fold
        set_seed(self.seed, bool(config["project"].get("deterministic", True)))
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.dataset = ReviewDataset(self.frame)
        model_cfg = config["model"]
        self.aspect_lexicon = load_lexicon(model_cfg["aspect_lexicon"])
        self.polarity_lexicon = load_lexicon(model_cfg["polarity_lexicon"])
        self.collator = ReviewBatchCollator(
            model_cfg["encoder_name"], self.aspect_lexicon, int(config["data"]["max_length"])
        )
        self.sampler = ClassBalancedSupportSampler(self.frame, fold.train, self.seed)
        self.model = self._new_model()
        self.logger = JsonlLogger(self.output_dir / "events.jsonl")
        self.best_state: dict[str, torch.Tensor] | None = None
        self.temperature = 1.0
        self.screening_threshold = 0.5
        self.best_epoch = 0

    def _new_model(self) -> RAMPFNet:
        return RAMPFNet(
            self.config, replace_prior_core=bool(self.variant.get("replace_prior_core", False))
        ).to(self.device)

    def _loader(self, indices: np.ndarray, shuffle: bool) -> DataLoader:
        generator = torch.Generator().manual_seed(self.seed)
        return DataLoader(
            Subset(self.dataset, indices.tolist()),
            batch_size=int(self.config["training"]["physical_batch_size"]),
            shuffle=shuffle,
            collate_fn=self.collator,
            generator=generator,
            num_workers=0,
        )

    def _records(self, indices: np.ndarray) -> list[ReviewRecord]:
        return [self.dataset[int(index)] for index in indices]

    def _support_batch(self, query_rows: np.ndarray, context: int) -> tuple[dict[str, Any], torch.Tensor, np.ndarray]:
        support_indices = self.sampler.sample(
            query_rows,
            size=int(self.config["model"]["support_size"]),
            context=context,
        )
        records = self._records(support_indices)
        batch = move_batch(self.collator(records), self.device)
        labels = batch["satisfaction"]
        return batch, labels, support_indices

    def _aspect_conflicts(self, records: list[ReviewRecord]) -> torch.Tensor:
        window = int(self.config["screening"]["polarity_window"])
        values = []
        for record in records:
            polarity = aspect_polarity(
                record.text, self.aspect_lexicon, self.polarity_lexicon, window=window
            )
            values.append(aspect_conflict_score(record.rating, polarity))
        return torch.tensor(values, dtype=torch.float32, device=self.device)

    def _class_weights(self, indices: np.ndarray) -> torch.Tensor:
        counts = self.frame.iloc[indices]["satisfaction"].value_counts().reindex([0, 1, 2]).to_numpy()
        weights = len(indices) / (3.0 * counts)
        return torch.tensor(weights, dtype=torch.float32, device=self.device)

    def _parameter_groups(self) -> list[dict[str, Any]]:
        training = self.config["training"]
        encoder_parameters = [p for p in self.model.encoder.parameters() if p.requires_grad]
        core_parameters = list(self.model.core.parameters())
        reserved = {id(parameter) for parameter in encoder_parameters + core_parameters}
        head_parameters = [
            parameter
            for parameter in self.model.parameters()
            if parameter.requires_grad and id(parameter) not in reserved
        ]
        return [
            {"params": encoder_parameters, "lr": float(training["encoder_learning_rate"])},
            {"params": core_parameters, "lr": float(training["core_learning_rate"])},
            {"params": head_parameters, "lr": float(training["head_learning_rate"])},
        ]

    def train_epoch(self, epoch: int, train_indices: np.ndarray) -> dict[str, float]:
        self.model.train()
        training = self.config["training"]
        optimizer = self.optimizer
        optimizer.zero_grad(set_to_none=True)
        class_weights = self._class_weights(train_indices)
        running = {key: 0.0 for key in ["total", "satisfaction", "ordinal", "inconsistency", "contrastive"]}
        steps = 0
        loader = self._loader(train_indices, shuffle=True)
        for batch_index, batch in enumerate(tqdm(loader, desc=f"fold {self.fold.fold} epoch {epoch}")):
            query_rows = batch["row_id"].numpy()
            query_records = self._records(query_rows)
            conflicts = self._aspect_conflicts(query_records)
            support_batch, support_labels, support_indices = self._support_batch(query_rows, context=batch_index)
            batch = move_batch(batch, self.device)
            support_batch = move_batch(support_batch, self.device)
            use_residual = bool(self.variant.get("use_ordinal_residual", True))
            use_gate = bool(self.variant.get("use_residual_gate", True))
            with torch.autocast(
                device_type=self.device.type,
                dtype=torch.bfloat16,
                enabled=self.device.type == "cuda" and training.get("mixed_precision") == "bf16",
            ):
                use_aspects = bool(self.variant.get("use_aspect_tokens", True))
                query_tokens, _ = self.model.encode(batch, use_aspects=use_aspects)
                with torch.no_grad():
                    support_tokens, _ = self.model.encode(support_batch, use_aspects=use_aspects)
                output = self.model.forward_from_tokens(
                    query_tokens,
                    support_tokens.detach(),
                    support_labels,
                    batch["rating"],
                    conflicts,
                    use_residual=use_residual,
                    use_gate=use_gate,
                )
                if not use_residual:
                    augmented_records = [
                        crop_and_drop(
                            record,
                            self.seed + epoch * 100000 + batch_index * 1000 + index,
                            float(training["token_dropout"]),
                            float(training["crop_min_fraction"]),
                        )
                        for index, record in enumerate(query_records)
                    ]
                    augmented_batch = move_batch(self.collator(augmented_records), self.device)
                    augmented_tokens, _ = self.model.encode(
                        augmented_batch, use_aspects=use_aspects
                    )
                    augmented_output = self.model.forward_from_tokens(
                        augmented_tokens, support_tokens.detach(), support_labels
                    )
                    satisfaction_loss = focal_loss(
                        output.satisfaction_logits,
                        batch["satisfaction"],
                        class_weights,
                        gamma=float(training["focal_gamma"]),
                    )
                    ordinal_loss = ordinal_cumulative_loss(
                        output.rating_probabilities, batch["rating"]
                    )
                    contrastive_value = contrastive_loss(
                        output.satisfaction_representation,
                        augmented_output.satisfaction_representation,
                        float(training["contrastive_temperature"]),
                    )
                    loss = (
                        satisfaction_loss
                        + float(training["lambda_ordinal"]) * ordinal_loss
                        + float(training["lambda_contrastive"]) * contrastive_value
                    )
                    loss_values = {
                        "total": loss,
                        "satisfaction": satisfaction_loss,
                        "ordinal": ordinal_loss,
                        "inconsistency": loss.new_zeros(()),
                        "contrastive": contrastive_value,
                    }
                else:
                    augmented_records = [
                        crop_and_drop(
                            record,
                            self.seed + epoch * 100000 + batch_index * 1000 + index,
                            float(training["token_dropout"]),
                            float(training["crop_min_fraction"]),
                        )
                        for index, record in enumerate(query_records)
                    ]
                    augmented_batch = move_batch(self.collator(augmented_records), self.device)
                    augmented_tokens, _ = self.model.encode(
                        augmented_batch, use_aspects=use_aspects
                    )
                    augmented_output = self.model.forward_from_tokens(
                        augmented_tokens, support_tokens.detach(), support_labels
                    )
                    weak_targets = operational_weak_targets(
                        output.residual_vector,
                        float(self.config["screening"]["absolute_deviation_threshold"]),
                        float(self.config["screening"]["posterior_confidence_threshold"]),
                        float(self.config["screening"]["aspect_conflict_threshold"]),
                    )
                    positives = weak_targets.sum().clamp_min(1.0)
                    positive_weight = ((len(weak_targets) - positives) / positives).clamp_min(1.0)
                    bundle = combined_loss(
                        output,
                        augmented_output.satisfaction_representation,
                        batch["satisfaction"],
                        batch["rating"],
                        class_weights,
                        positive_weight,
                        self.config,
                    )
                    loss = bundle.total
                    loss_values = asdict(bundle)
                scaled = loss / int(training["gradient_accumulation"])
            scaled.backward()
            if (batch_index + 1) % int(training["gradient_accumulation"]) == 0:
                nn.utils.clip_grad_norm_(self.model.parameters(), float(training["gradient_clip"]))
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
            for key in running:
                running[key] += float(loss_values[key].detach().cpu())
            steps += 1
            if self.config["logging"].get("save_support_indices", True):
                target = self.output_dir / "support_indices" / f"epoch_{epoch}_batch_{batch_index}.npy"
                target.parent.mkdir(parents=True, exist_ok=True)
                np.save(target, support_indices)
        return {key: value / max(steps, 1) for key, value in running.items()}

    @torch.no_grad()
    def predict(self, indices: np.ndarray, contexts: int | None = None) -> dict[str, np.ndarray]:
        self.model.eval()
        contexts = contexts or int(self.config["model"]["support_contexts"])
        collected: dict[str, list[np.ndarray]] = {
            "row_id": [],
            "label": [],
            "rating": [],
            "satisfaction_probabilities": [],
            "satisfaction_logits": [],
            "rating_probabilities": [],
            "implied_rating": [],
            "residual_vector": [],
            "inconsistency_probability": [],
        }
        for batch_index, batch in enumerate(self._loader(indices, shuffle=False)):
            rows = batch["row_id"].numpy()
            records = self._records(rows)
            conflicts = self._aspect_conflicts(records)
            batch_device = move_batch(batch, self.device)
            use_aspects = bool(self.variant.get("use_aspect_tokens", True))
            query_tokens, _ = self.model.encode(batch_device, use_aspects=use_aspects)
            outputs = []
            for context in range(contexts):
                support_batch, support_labels, _ = self._support_batch(rows, context=context)
                support_tokens, _ = self.model.encode(
                    move_batch(support_batch, self.device), use_aspects=use_aspects
                )
                outputs.append(
                    self.model.forward_from_tokens(
                        query_tokens,
                        support_tokens,
                        support_labels,
                        batch_device["rating"],
                        conflicts,
                        use_residual=bool(self.variant.get("use_ordinal_residual", True)),
                        use_gate=bool(self.variant.get("use_residual_gate", True)),
                    )
                )
            satisfaction = torch.stack([value.satisfaction_probabilities for value in outputs]).mean(0)
            logits = torch.log(satisfaction.clamp_min(1e-8))
            rating = torch.stack([value.rating_probabilities for value in outputs]).mean(0)
            implied = torch.stack([value.implied_rating for value in outputs]).mean(0)
            if outputs[0].residual_vector is None:
                residual = torch.full((len(rows), 7), torch.nan, device=self.device)
                inconsistency = torch.full((len(rows),), torch.nan, device=self.device)
            else:
                residual = torch.stack([value.residual_vector for value in outputs]).mean(0)
                inconsistency = torch.stack(
                    [value.inconsistency_probabilities for value in outputs]
                ).mean(0)
            values = {
                "row_id": rows,
                "label": batch["satisfaction"].numpy(),
                "rating": batch["rating"].numpy(),
                "satisfaction_probabilities": satisfaction.cpu().numpy(),
                "satisfaction_logits": logits.cpu().numpy(),
                "rating_probabilities": rating.cpu().numpy(),
                "implied_rating": implied.cpu().numpy(),
                "residual_vector": residual.cpu().numpy(),
                "inconsistency_probability": inconsistency.cpu().numpy(),
            }
            for key, value in values.items():
                collected[key].append(np.asarray(value))
        return {key: np.concatenate(value, axis=0) for key, value in collected.items()}

    def fit(self, fit_indices: np.ndarray, validation_indices: np.ndarray) -> dict[str, Any]:
        training = self.config["training"]
        self.optimizer = AdamW(
            self._parameter_groups(), weight_decay=float(training["weight_decay"])
        )
        best_score = -np.inf
        remaining_patience = int(training["patience"])
        history = []
        for epoch in range(1, int(training["epochs"]) + 1):
            losses = self.train_epoch(epoch, fit_indices)
            prediction = self.predict(validation_indices, contexts=1)
            metrics = classification_metrics(
                prediction["label"], prediction["satisfaction_probabilities"]
            )
            history.append({"epoch": epoch, "losses": losses, "metrics": metrics})
            self.logger.log("epoch_complete", epoch=epoch, losses=losses, metrics=metrics)
            if metrics["macro_f1"] > best_score:
                best_score = metrics["macro_f1"]
                self.best_state = {
                    key: value.detach().cpu().clone() for key, value in self.model.state_dict().items()
                }
                remaining_patience = int(training["patience"])
                self.best_epoch = epoch
            else:
                remaining_patience -= 1
                if remaining_patience <= 0:
                    break
        if self.best_state is None:
            raise RuntimeError("No checkpoint selected")
        self.model.load_state_dict(self.best_state)
        validation = self.predict(validation_indices)
        self.temperature = fit_temperature(validation["satisfaction_logits"], validation["label"])
        residual = validation["residual_vector"]
        if np.isfinite(residual).all():
            residual_tensor = torch.tensor(residual)
            weak = operational_weak_targets(
                residual_tensor,
                float(self.config["screening"]["absolute_deviation_threshold"]),
                float(self.config["screening"]["posterior_confidence_threshold"]),
                float(self.config["screening"]["aspect_conflict_threshold"]),
            ).numpy()
            screening = self.config["screening"]
            grid = np.arange(
                float(screening["threshold_grid_start"]),
                float(screening["threshold_grid_stop"]) + 1e-9,
                float(screening["threshold_grid_step"]),
            )
            self.screening_threshold = select_f1_threshold(
                weak, validation["inconsistency_probability"], grid
            )
        write_json(
            self.output_dir / "selection.json",
            {
                "best_macro_f1": best_score,
                "temperature": self.temperature,
                "screening_threshold": self.screening_threshold,
                "history": history,
            },
        )
        return {"macro_f1": best_score, "epochs": len(history), "best_epoch": self.best_epoch}

    def refit(self, train_indices: np.ndarray) -> None:
        if self.best_epoch < 1:
            raise RuntimeError("Inner selection must complete before outer-training refit")
        locked_temperature = self.temperature
        locked_threshold = self.screening_threshold
        set_seed(self.seed, bool(self.config["project"].get("deterministic", True)))
        self.model = self._new_model()
        self.optimizer = AdamW(
            self._parameter_groups(), weight_decay=float(self.config["training"]["weight_decay"])
        )
        for epoch in range(1, self.best_epoch + 1):
            losses = self.train_epoch(epoch, train_indices)
            self.logger.log("refit_epoch_complete", epoch=epoch, losses=losses)
        self.temperature = locked_temperature
        self.screening_threshold = locked_threshold
        self.logger.log(
            "refit_complete",
            epochs=self.best_epoch,
            locked_temperature=self.temperature,
            locked_screening_threshold=self.screening_threshold,
        )

    def evaluate_and_save(self, indices: np.ndarray, name: str) -> dict[str, Any]:
        prediction = self.predict(indices)
        calibrated = apply_temperature(prediction["satisfaction_logits"], self.temperature)
        class_metrics = classification_metrics(prediction["label"], calibrated)
        result: dict[str, Any] = {"classification": class_metrics}
        if np.isfinite(prediction["residual_vector"]).all():
            weak = operational_weak_targets(
                torch.tensor(prediction["residual_vector"]),
                float(self.config["screening"]["absolute_deviation_threshold"]),
                float(self.config["screening"]["posterior_confidence_threshold"]),
                float(self.config["screening"]["aspect_conflict_threshold"]),
            ).numpy()
            result["screening"] = screening_metrics(
                weak,
                prediction["inconsistency_probability"],
                self.screening_threshold,
            )
        output = pd.DataFrame(
            {
                "row_id": prediction["row_id"],
                "label": prediction["label"],
                "rating": prediction["rating"],
                "p_low": calibrated[:, 0],
                "p_medium": calibrated[:, 1],
                "p_high": calibrated[:, 2],
                "implied_rating": prediction["implied_rating"],
                "inconsistency_probability": prediction["inconsistency_probability"],
            }
        )
        if np.isfinite(prediction["residual_vector"]).all():
            for index in range(7):
                output[f"residual_{index}"] = prediction["residual_vector"][:, index]
            output["weak_target"] = operational_weak_targets(
                torch.tensor(prediction["residual_vector"]),
                float(self.config["screening"]["absolute_deviation_threshold"]),
                float(self.config["screening"]["posterior_confidence_threshold"]),
                float(self.config["screening"]["aspect_conflict_threshold"]),
            ).numpy().astype(int)
        output.to_csv(self.output_dir / f"{name}_predictions.csv.gz", index=False)
        torch.save(self.model.state_dict(), self.output_dir / "model.pt")
        write_json(self.output_dir / f"{name}_metrics.json", result)
        self.logger.log("evaluation_complete", partition=name, metrics=result)
        return result


def aggregate_fold_metrics(metrics: list[dict[str, Any]]) -> dict[str, Any]:
    keys = sorted(metrics[0]["classification"])
    return {
        key: {
            "folds": [float(item["classification"][key]) for item in metrics],
            "mean": float(np.mean([item["classification"][key] for item in metrics])),
            "sd": float(np.std([item["classification"][key] for item in metrics], ddof=1)),
        }
        for key in keys
    }

