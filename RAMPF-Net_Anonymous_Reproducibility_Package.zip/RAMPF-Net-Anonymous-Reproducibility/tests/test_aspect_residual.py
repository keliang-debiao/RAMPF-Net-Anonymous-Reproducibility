from rampfnet.aspects import AspectPolarity, aspect_conflict_score, aspect_polarity


def test_aspect_conflict_mapping():
    polarity = AspectPolarity(positive_share=0.75, negative_share=0.25, mentioned_count=4)
    assert aspect_conflict_score(5, polarity) == 0.25
    assert aspect_conflict_score(1, polarity) == 0.75
    assert aspect_conflict_score(3, polarity) == 0.25
    assert aspect_conflict_score(5, AspectPolarity(0.0, 0.0, 0)) == 0.0


def test_local_polarity_window():
    aspects = {"service": ["staff"], "cleanliness": ["clean"]}
    polarity_words = {"positive": ["great", "clean"], "negative": ["rude", "dirty"]}
    value = aspect_polarity("great staff but the bathroom was dirty", aspects, polarity_words, window=2)
    assert value.mentioned_count == 1
    assert value.positive_share == 1.0

