import numpy as np
import pandas as pd

from rampfnet.data import audit_frame, normalize_text, satisfaction_label
from rampfnet.splits import ClassBalancedSupportSampler, make_outer_folds


def test_normalization_and_mapping():
    assert normalize_text(" A\u00a0hotel   http://host.test ") == "A hotel <URL>"
    assert [satisfaction_label(value) for value in range(1, 6)] == [0, 0, 1, 2, 2]


def test_grouped_folds_and_support_exclusion():
    rows = []
    for label, rating in enumerate([1, 3, 5]):
        for index in range(30):
            rows.append({"Review": f"review {label} {index}", "Rating": rating})
    rows.extend([{"Review": "duplicate review", "Rating": 1}] * 3)
    frame = audit_frame(pd.DataFrame(rows), "unit")
    folds = make_outer_folds(frame, n_splits=3, seed=17, inner_fraction=0.2)
    duplicate_hash = frame.loc[frame.text == "duplicate review", "text_hash"].iloc[0]
    for fold in folds:
        partitions = [fold.inner_train, fold.inner_validation, fold.test]
        membership = [duplicate_hash in set(frame.iloc[index]["text_hash"]) for index in partitions]
        assert sum(membership) == 1
        query = fold.test[:2]
        sampler = ClassBalancedSupportSampler(frame, fold.train, seed=17)
        support = sampler.sample(query, size=12)
        assert not np.intersect1d(query, support).size
        query_hashes = set(frame.iloc[query]["text_hash"])
        assert not query_hashes.intersection(set(frame.iloc[support]["text_hash"]))

