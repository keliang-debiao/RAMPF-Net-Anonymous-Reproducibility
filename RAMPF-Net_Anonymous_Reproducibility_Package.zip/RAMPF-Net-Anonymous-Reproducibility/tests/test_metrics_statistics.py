import numpy as np

from rampfnet.metrics import calibration_errors, classification_metrics, multiclass_brier
from rampfnet.statistics import corrected_resampled_test, holm_adjust


def test_metric_values_are_finite():
    labels = np.array([0, 1, 2, 2])
    probabilities = np.array(
        [[0.8, 0.1, 0.1], [0.2, 0.6, 0.2], [0.1, 0.2, 0.7], [0.2, 0.3, 0.5]]
    )
    assert 0 <= multiclass_brier(labels, probabilities) <= 2
    ece, mce = calibration_errors(labels, probabilities, bins=5)
    assert 0 <= ece <= mce <= 1
    assert all(np.isfinite(list(classification_metrics(labels, probabilities).values())))


def test_corrected_comparison_and_holm():
    proposed = np.array([0.742, 0.733, 0.747, 0.737, 0.743])
    comparator = proposed - np.array([0.004, 0.003, 0.005, 0.004, 0.004])
    result = corrected_resampled_test(proposed, comparator)
    assert result.mean_difference > 0
    adjusted = holm_adjust([0.001, 0.01, 0.04])
    assert all(0 <= value <= 1 for value in adjusted)

