import pytest


torch = pytest.importorskip("torch")
nn = torch.nn

from rampfnet.model import MLPContextCore, OrdinalResidualTokenizer, RAMPFNet


def build_head_only_model(dim: int = 8):
    model = RAMPFNet.__new__(RAMPFNet)
    nn.Module.__init__(model)
    model.core = MLPContextCore(dim, 0.0)
    model.satisfaction_projection = nn.Linear(dim, dim)
    model.rating_projection = nn.Linear(dim, dim)
    model.satisfaction_head = nn.Linear(dim, 3)
    model.rating_head = nn.Linear(dim, 5)
    model.residual_tokenizer = OrdinalResidualTokenizer(dim)
    model.residual_gate = nn.Sequential(nn.Linear(dim + 2, 1), nn.Sigmoid())
    model.inconsistency_head = nn.Linear(dim * 2, 1)
    return model.eval()


def test_observed_rating_cannot_change_satisfaction_output():
    torch.manual_seed(7)
    model = build_head_only_model()
    query = torch.randn(4, 3, 8)
    support = torch.randn(9, 3, 8)
    labels = torch.tensor([0, 1, 2, 0, 1, 2, 0, 1, 2])
    conflict = torch.zeros(4)
    first = model.forward_from_tokens(query, support, labels, torch.ones(4), conflict)
    second = model.forward_from_tokens(query, support, labels, torch.full((4,), 5.0), conflict)
    assert torch.equal(first.satisfaction_logits, second.satisfaction_logits)
    assert not torch.equal(first.residual_vector, second.residual_vector)

