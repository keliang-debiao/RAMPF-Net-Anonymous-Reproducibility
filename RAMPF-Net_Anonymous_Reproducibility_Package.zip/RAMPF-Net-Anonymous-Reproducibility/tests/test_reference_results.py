from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]


def test_internal_fold_arithmetic():
    frame = pd.read_csv(ROOT / "reference_results" / "internal_folds.csv")
    folds = frame[frame["split"].str.startswith("fold_")]
    mean = frame[frame["split"] == "mean"].iloc[0]
    sd = frame[frame["split"] == "sd"].iloc[0]
    metrics = ["accuracy", "macro_f1", "weighted_f1", "qwk", "mae", "rmse", "brier", "ece"]
    for metric in metrics:
        assert round(folds[metric].mean(), 3) == round(mean[metric], 3)
        assert round(folds[metric].std(ddof=1), 3) == round(sd[metric], 3)


def test_interpretability_share():
    frame = pd.read_csv(ROOT / "reference_results" / "interpretability.csv")
    aspects = frame[frame["analysis"] == "aspect_attribution"]
    assert round(aspects["estimate"].sum(), 3) == 1.000


def test_external_is_lower_than_internal():
    internal = pd.read_csv(ROOT / "reference_results" / "internal_folds.csv")
    external = pd.read_csv(ROOT / "reference_results" / "external.csv")
    internal_macro = float(internal.loc[internal["split"] == "mean", "macro_f1"].iloc[0])
    external_macro = float(external.loc[external["model"] == "RAMPF-Net", "macro_f1"].iloc[0])
    assert round(internal_macro - external_macro, 3) == 0.098

